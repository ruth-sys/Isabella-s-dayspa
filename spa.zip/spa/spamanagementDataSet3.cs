﻿namespace spa
{


    partial class spamanagementDataSet3
    {
    }
}

namespace spa.spamanagementDataSet3TableAdapters {
    
    
    public partial class appointmentTableAdapter {
    }
}
