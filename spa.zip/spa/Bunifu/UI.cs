﻿namespace Bunifu
{
    internal class UI
    {
    }
}