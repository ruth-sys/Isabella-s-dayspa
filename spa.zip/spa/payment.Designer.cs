﻿namespace spa
{
    partial class payment
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(payment));
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblusername = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.bunifuFlatButton1 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnlogout = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnrecievepay = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnsetappoint = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btndash = new Bunifu.Framework.UI.BunifuFlatButton();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnclose = new System.Windows.Forms.Button();
            this.lblnameemployee = new System.Windows.Forms.Label();
            this.imguserlogin = new System.Windows.Forms.PictureBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.btncreatecust = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnsignout = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnpay = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnappoint = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnhome = new Bunifu.Framework.UI.BunifuFlatButton();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.btnprintrecipt = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.btnsearchid = new System.Windows.Forms.Button();
            this.lblprice = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtamt = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.lblname = new System.Windows.Forms.Label();
            this.txtname = new System.Windows.Forms.TextBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.label12 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lblchange = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.lblyourcash = new System.Windows.Forms.Label();
            this.lblservicedet = new System.Windows.Forms.Label();
            this.lblservicenum = new System.Windows.Forms.Label();
            this.lblcostof1 = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.lblServiceName = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lbldate = new System.Windows.Forms.Label();
            this.lbltotcost = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.bunifuDragControl1 = new Bunifu.Framework.UI.BunifuDragControl(this.components);
            this.btnprint = new System.Windows.Forms.Button();
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            this.printPreviewDialog1 = new System.Windows.Forms.PrintPreviewDialog();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.imguserlogin)).BeginInit();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.panel6.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.DimGray;
            this.panel1.Controls.Add(this.lblusername);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.btnclose);
            this.panel1.Controls.Add(this.lblnameemployee);
            this.panel1.Controls.Add(this.imguserlogin);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(923, 76);
            this.panel1.TabIndex = 2;
            // 
            // lblusername
            // 
            this.lblusername.AutoSize = true;
            this.lblusername.Font = new System.Drawing.Font("Brush Script MT", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblusername.Location = new System.Drawing.Point(89, 45);
            this.lblusername.Name = "lblusername";
            this.lblusername.Size = new System.Drawing.Size(131, 17);
            this.lblusername.TabIndex = 41;
            this.lblusername.Text = "Username of Employee";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.DimGray;
            this.panel2.Controls.Add(this.bunifuFlatButton1);
            this.panel2.Controls.Add(this.btnlogout);
            this.panel2.Controls.Add(this.btnrecievepay);
            this.panel2.Controls.Add(this.btnsetappoint);
            this.panel2.Controls.Add(this.btndash);
            this.panel2.Controls.Add(this.pictureBox1);
            this.panel2.Location = new System.Drawing.Point(0, 82);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(249, 496);
            this.panel2.TabIndex = 4;
            // 
            // bunifuFlatButton1
            // 
            this.bunifuFlatButton1.Activecolor = System.Drawing.Color.DimGray;
            this.bunifuFlatButton1.BackColor = System.Drawing.Color.DimGray;
            this.bunifuFlatButton1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton1.BorderRadius = 0;
            this.bunifuFlatButton1.ButtonText = "  CREATE NEW CUSTOMER";
            this.bunifuFlatButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton1.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton1.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton1.Iconimage = global::spa.Properties.Resources.customer;
            this.bunifuFlatButton1.Iconimage_right = null;
            this.bunifuFlatButton1.Iconimage_right_Selected = null;
            this.bunifuFlatButton1.Iconimage_Selected = null;
            this.bunifuFlatButton1.IconMarginLeft = 0;
            this.bunifuFlatButton1.IconMarginRight = 0;
            this.bunifuFlatButton1.IconRightVisible = true;
            this.bunifuFlatButton1.IconRightZoom = 0D;
            this.bunifuFlatButton1.IconVisible = true;
            this.bunifuFlatButton1.IconZoom = 60D;
            this.bunifuFlatButton1.IsTab = false;
            this.bunifuFlatButton1.Location = new System.Drawing.Point(0, 198);
            this.bunifuFlatButton1.Name = "bunifuFlatButton1";
            this.bunifuFlatButton1.Normalcolor = System.Drawing.Color.DimGray;
            this.bunifuFlatButton1.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.bunifuFlatButton1.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton1.selected = false;
            this.bunifuFlatButton1.Size = new System.Drawing.Size(241, 48);
            this.bunifuFlatButton1.TabIndex = 7;
            this.bunifuFlatButton1.Text = "  CREATE NEW CUSTOMER";
            this.bunifuFlatButton1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bunifuFlatButton1.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton1.TextFont = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // btnlogout
            // 
            this.btnlogout.Activecolor = System.Drawing.Color.DimGray;
            this.btnlogout.BackColor = System.Drawing.Color.DimGray;
            this.btnlogout.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnlogout.BorderRadius = 0;
            this.btnlogout.ButtonText = "";
            this.btnlogout.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnlogout.DisabledColor = System.Drawing.Color.Gray;
            this.btnlogout.Iconcolor = System.Drawing.Color.Transparent;
            this.btnlogout.Iconimage = global::spa.Properties.Resources.logout;
            this.btnlogout.Iconimage_right = null;
            this.btnlogout.Iconimage_right_Selected = null;
            this.btnlogout.Iconimage_Selected = null;
            this.btnlogout.IconMarginLeft = 0;
            this.btnlogout.IconMarginRight = 0;
            this.btnlogout.IconRightVisible = true;
            this.btnlogout.IconRightZoom = 0D;
            this.btnlogout.IconVisible = true;
            this.btnlogout.IconZoom = 60D;
            this.btnlogout.IsTab = false;
            this.btnlogout.Location = new System.Drawing.Point(82, 405);
            this.btnlogout.Name = "btnlogout";
            this.btnlogout.Normalcolor = System.Drawing.Color.DimGray;
            this.btnlogout.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.btnlogout.OnHoverTextColor = System.Drawing.Color.White;
            this.btnlogout.selected = false;
            this.btnlogout.Size = new System.Drawing.Size(48, 48);
            this.btnlogout.TabIndex = 6;
            this.btnlogout.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnlogout.Textcolor = System.Drawing.Color.White;
            this.btnlogout.TextFont = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // btnrecievepay
            // 
            this.btnrecievepay.Activecolor = System.Drawing.Color.DimGray;
            this.btnrecievepay.BackColor = System.Drawing.Color.DimGray;
            this.btnrecievepay.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnrecievepay.BorderRadius = 0;
            this.btnrecievepay.ButtonText = "  RECIEVE PAYEMENT";
            this.btnrecievepay.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnrecievepay.DisabledColor = System.Drawing.Color.Gray;
            this.btnrecievepay.Iconcolor = System.Drawing.Color.Transparent;
            this.btnrecievepay.Iconimage = global::spa.Properties.Resources.payment;
            this.btnrecievepay.Iconimage_right = null;
            this.btnrecievepay.Iconimage_right_Selected = null;
            this.btnrecievepay.Iconimage_Selected = null;
            this.btnrecievepay.IconMarginLeft = 0;
            this.btnrecievepay.IconMarginRight = 0;
            this.btnrecievepay.IconRightVisible = true;
            this.btnrecievepay.IconRightZoom = 0D;
            this.btnrecievepay.IconVisible = true;
            this.btnrecievepay.IconZoom = 60D;
            this.btnrecievepay.IsTab = false;
            this.btnrecievepay.Location = new System.Drawing.Point(0, 351);
            this.btnrecievepay.Name = "btnrecievepay";
            this.btnrecievepay.Normalcolor = System.Drawing.Color.DimGray;
            this.btnrecievepay.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.btnrecievepay.OnHoverTextColor = System.Drawing.Color.White;
            this.btnrecievepay.selected = false;
            this.btnrecievepay.Size = new System.Drawing.Size(241, 48);
            this.btnrecievepay.TabIndex = 5;
            this.btnrecievepay.Text = "  RECIEVE PAYEMENT";
            this.btnrecievepay.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnrecievepay.Textcolor = System.Drawing.Color.White;
            this.btnrecievepay.TextFont = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // btnsetappoint
            // 
            this.btnsetappoint.Activecolor = System.Drawing.Color.DimGray;
            this.btnsetappoint.BackColor = System.Drawing.Color.DimGray;
            this.btnsetappoint.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnsetappoint.BorderRadius = 0;
            this.btnsetappoint.ButtonText = "  SET APPOINTMENT";
            this.btnsetappoint.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnsetappoint.DisabledColor = System.Drawing.Color.Gray;
            this.btnsetappoint.Iconcolor = System.Drawing.Color.Transparent;
            this.btnsetappoint.Iconimage = global::spa.Properties.Resources.appointment;
            this.btnsetappoint.Iconimage_right = null;
            this.btnsetappoint.Iconimage_right_Selected = null;
            this.btnsetappoint.Iconimage_Selected = null;
            this.btnsetappoint.IconMarginLeft = 0;
            this.btnsetappoint.IconMarginRight = 0;
            this.btnsetappoint.IconRightVisible = true;
            this.btnsetappoint.IconRightZoom = 0D;
            this.btnsetappoint.IconVisible = true;
            this.btnsetappoint.IconZoom = 60D;
            this.btnsetappoint.IsTab = false;
            this.btnsetappoint.Location = new System.Drawing.Point(0, 273);
            this.btnsetappoint.Name = "btnsetappoint";
            this.btnsetappoint.Normalcolor = System.Drawing.Color.DimGray;
            this.btnsetappoint.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.btnsetappoint.OnHoverTextColor = System.Drawing.Color.White;
            this.btnsetappoint.selected = false;
            this.btnsetappoint.Size = new System.Drawing.Size(241, 48);
            this.btnsetappoint.TabIndex = 4;
            this.btnsetappoint.Text = "  SET APPOINTMENT";
            this.btnsetappoint.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnsetappoint.Textcolor = System.Drawing.Color.White;
            this.btnsetappoint.TextFont = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // btndash
            // 
            this.btndash.Activecolor = System.Drawing.Color.DimGray;
            this.btndash.BackColor = System.Drawing.Color.DimGray;
            this.btndash.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btndash.BorderRadius = 0;
            this.btndash.ButtonText = "    DASHBOARD";
            this.btndash.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btndash.DisabledColor = System.Drawing.Color.Gray;
            this.btndash.Iconcolor = System.Drawing.Color.Transparent;
            this.btndash.Iconimage = global::spa.Properties.Resources.dashboard;
            this.btndash.Iconimage_right = null;
            this.btndash.Iconimage_right_Selected = null;
            this.btndash.Iconimage_Selected = null;
            this.btndash.IconMarginLeft = 0;
            this.btndash.IconMarginRight = 0;
            this.btndash.IconRightVisible = true;
            this.btndash.IconRightZoom = 0D;
            this.btndash.IconVisible = true;
            this.btndash.IconZoom = 60D;
            this.btndash.IsTab = false;
            this.btndash.Location = new System.Drawing.Point(0, 124);
            this.btndash.Name = "btndash";
            this.btndash.Normalcolor = System.Drawing.Color.DimGray;
            this.btndash.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.btndash.OnHoverTextColor = System.Drawing.Color.White;
            this.btndash.selected = false;
            this.btndash.Size = new System.Drawing.Size(241, 48);
            this.btndash.TabIndex = 3;
            this.btndash.Text = "    DASHBOARD";
            this.btndash.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btndash.Textcolor = System.Drawing.Color.White;
            this.btndash.TextFont = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::spa.Properties.Resources.logo;
            this.pictureBox1.Location = new System.Drawing.Point(29, 17);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(171, 76);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // btnclose
            // 
            this.btnclose.BackgroundImage = global::spa.Properties.Resources.close_button;
            this.btnclose.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnclose.Location = new System.Drawing.Point(882, 0);
            this.btnclose.Name = "btnclose";
            this.btnclose.Size = new System.Drawing.Size(38, 23);
            this.btnclose.TabIndex = 10;
            this.btnclose.UseVisualStyleBackColor = true;
            this.btnclose.Click += new System.EventHandler(this.btnclose_Click);
            // 
            // lblnameemployee
            // 
            this.lblnameemployee.AutoSize = true;
            this.lblnameemployee.Font = new System.Drawing.Font("Bradley Hand ITC", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblnameemployee.Location = new System.Drawing.Point(87, 12);
            this.lblnameemployee.Name = "lblnameemployee";
            this.lblnameemployee.Size = new System.Drawing.Size(216, 30);
            this.lblnameemployee.TabIndex = 2;
            this.lblnameemployee.Text = "Name of Employee";
            // 
            // imguserlogin
            // 
            this.imguserlogin.Image = global::spa.Properties.Resources.usernamelogin;
            this.imguserlogin.Location = new System.Drawing.Point(29, 12);
            this.imguserlogin.Name = "imguserlogin";
            this.imguserlogin.Size = new System.Drawing.Size(52, 47);
            this.imguserlogin.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.imguserlogin.TabIndex = 1;
            this.imguserlogin.TabStop = false;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.DimGray;
            this.panel3.Controls.Add(this.btncreatecust);
            this.panel3.Controls.Add(this.btnsignout);
            this.panel3.Controls.Add(this.btnpay);
            this.panel3.Controls.Add(this.btnappoint);
            this.panel3.Controls.Add(this.btnhome);
            this.panel3.Controls.Add(this.pictureBox2);
            this.panel3.Location = new System.Drawing.Point(0, 65);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(249, 810);
            this.panel3.TabIndex = 4;
            // 
            // btncreatecust
            // 
            this.btncreatecust.Activecolor = System.Drawing.Color.DimGray;
            this.btncreatecust.BackColor = System.Drawing.Color.DimGray;
            this.btncreatecust.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btncreatecust.BorderRadius = 0;
            this.btncreatecust.ButtonText = "  CREATE NEW CUSTOMER";
            this.btncreatecust.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btncreatecust.DisabledColor = System.Drawing.Color.Gray;
            this.btncreatecust.Iconcolor = System.Drawing.Color.Transparent;
            this.btncreatecust.Iconimage = global::spa.Properties.Resources.customer;
            this.btncreatecust.Iconimage_right = null;
            this.btncreatecust.Iconimage_right_Selected = null;
            this.btncreatecust.Iconimage_Selected = null;
            this.btncreatecust.IconMarginLeft = 0;
            this.btncreatecust.IconMarginRight = 0;
            this.btncreatecust.IconRightVisible = true;
            this.btncreatecust.IconRightZoom = 0D;
            this.btncreatecust.IconVisible = true;
            this.btncreatecust.IconZoom = 60D;
            this.btncreatecust.IsTab = false;
            this.btncreatecust.Location = new System.Drawing.Point(0, 198);
            this.btncreatecust.Name = "btncreatecust";
            this.btncreatecust.Normalcolor = System.Drawing.Color.DimGray;
            this.btncreatecust.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.btncreatecust.OnHoverTextColor = System.Drawing.Color.White;
            this.btncreatecust.selected = false;
            this.btncreatecust.Size = new System.Drawing.Size(241, 48);
            this.btncreatecust.TabIndex = 7;
            this.btncreatecust.Text = "  CREATE NEW CUSTOMER";
            this.btncreatecust.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btncreatecust.Textcolor = System.Drawing.Color.White;
            this.btncreatecust.TextFont = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncreatecust.Click += new System.EventHandler(this.btncreatecust_Click);
            // 
            // btnsignout
            // 
            this.btnsignout.Activecolor = System.Drawing.Color.DimGray;
            this.btnsignout.BackColor = System.Drawing.Color.DimGray;
            this.btnsignout.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnsignout.BorderRadius = 0;
            this.btnsignout.ButtonText = "";
            this.btnsignout.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnsignout.DisabledColor = System.Drawing.Color.Gray;
            this.btnsignout.Iconcolor = System.Drawing.Color.Transparent;
            this.btnsignout.Iconimage = global::spa.Properties.Resources.logout;
            this.btnsignout.Iconimage_right = null;
            this.btnsignout.Iconimage_right_Selected = null;
            this.btnsignout.Iconimage_Selected = null;
            this.btnsignout.IconMarginLeft = 0;
            this.btnsignout.IconMarginRight = 0;
            this.btnsignout.IconRightVisible = true;
            this.btnsignout.IconRightZoom = 0D;
            this.btnsignout.IconVisible = true;
            this.btnsignout.IconZoom = 60D;
            this.btnsignout.IsTab = false;
            this.btnsignout.Location = new System.Drawing.Point(92, 462);
            this.btnsignout.Name = "btnsignout";
            this.btnsignout.Normalcolor = System.Drawing.Color.DimGray;
            this.btnsignout.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.btnsignout.OnHoverTextColor = System.Drawing.Color.White;
            this.btnsignout.selected = false;
            this.btnsignout.Size = new System.Drawing.Size(48, 48);
            this.btnsignout.TabIndex = 6;
            this.btnsignout.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnsignout.Textcolor = System.Drawing.Color.White;
            this.btnsignout.TextFont = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsignout.Click += new System.EventHandler(this.btnsignout_Click);
            // 
            // btnpay
            // 
            this.btnpay.Activecolor = System.Drawing.Color.Lime;
            this.btnpay.BackColor = System.Drawing.Color.Lime;
            this.btnpay.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnpay.BorderRadius = 0;
            this.btnpay.ButtonText = "  RECIEVE PAYEMENT";
            this.btnpay.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnpay.DisabledColor = System.Drawing.Color.Gray;
            this.btnpay.Iconcolor = System.Drawing.Color.Transparent;
            this.btnpay.Iconimage = global::spa.Properties.Resources.payment;
            this.btnpay.Iconimage_right = null;
            this.btnpay.Iconimage_right_Selected = null;
            this.btnpay.Iconimage_Selected = null;
            this.btnpay.IconMarginLeft = 0;
            this.btnpay.IconMarginRight = 0;
            this.btnpay.IconRightVisible = true;
            this.btnpay.IconRightZoom = 0D;
            this.btnpay.IconVisible = true;
            this.btnpay.IconZoom = 60D;
            this.btnpay.IsTab = false;
            this.btnpay.Location = new System.Drawing.Point(0, 351);
            this.btnpay.Name = "btnpay";
            this.btnpay.Normalcolor = System.Drawing.Color.Lime;
            this.btnpay.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.btnpay.OnHoverTextColor = System.Drawing.Color.White;
            this.btnpay.selected = true;
            this.btnpay.Size = new System.Drawing.Size(241, 48);
            this.btnpay.TabIndex = 5;
            this.btnpay.Text = "  RECIEVE PAYEMENT";
            this.btnpay.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnpay.Textcolor = System.Drawing.Color.White;
            this.btnpay.TextFont = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnpay.Click += new System.EventHandler(this.btnpay_Click);
            // 
            // btnappoint
            // 
            this.btnappoint.Activecolor = System.Drawing.Color.DimGray;
            this.btnappoint.BackColor = System.Drawing.Color.DimGray;
            this.btnappoint.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnappoint.BorderRadius = 0;
            this.btnappoint.ButtonText = "  SET APPOINTMENT";
            this.btnappoint.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnappoint.DisabledColor = System.Drawing.Color.Gray;
            this.btnappoint.Iconcolor = System.Drawing.Color.Transparent;
            this.btnappoint.Iconimage = global::spa.Properties.Resources.appointment;
            this.btnappoint.Iconimage_right = null;
            this.btnappoint.Iconimage_right_Selected = null;
            this.btnappoint.Iconimage_Selected = null;
            this.btnappoint.IconMarginLeft = 0;
            this.btnappoint.IconMarginRight = 0;
            this.btnappoint.IconRightVisible = true;
            this.btnappoint.IconRightZoom = 0D;
            this.btnappoint.IconVisible = true;
            this.btnappoint.IconZoom = 60D;
            this.btnappoint.IsTab = false;
            this.btnappoint.Location = new System.Drawing.Point(0, 273);
            this.btnappoint.Name = "btnappoint";
            this.btnappoint.Normalcolor = System.Drawing.Color.DimGray;
            this.btnappoint.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.btnappoint.OnHoverTextColor = System.Drawing.Color.White;
            this.btnappoint.selected = false;
            this.btnappoint.Size = new System.Drawing.Size(241, 48);
            this.btnappoint.TabIndex = 4;
            this.btnappoint.Text = "  SET APPOINTMENT";
            this.btnappoint.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnappoint.Textcolor = System.Drawing.Color.White;
            this.btnappoint.TextFont = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnappoint.Click += new System.EventHandler(this.btnappoint_Click);
            // 
            // btnhome
            // 
            this.btnhome.Activecolor = System.Drawing.Color.DimGray;
            this.btnhome.BackColor = System.Drawing.Color.DimGray;
            this.btnhome.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnhome.BorderRadius = 0;
            this.btnhome.ButtonText = "    DASHBOARD";
            this.btnhome.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnhome.DisabledColor = System.Drawing.Color.Gray;
            this.btnhome.Iconcolor = System.Drawing.Color.Transparent;
            this.btnhome.Iconimage = global::spa.Properties.Resources.dashboard;
            this.btnhome.Iconimage_right = null;
            this.btnhome.Iconimage_right_Selected = null;
            this.btnhome.Iconimage_Selected = null;
            this.btnhome.IconMarginLeft = 0;
            this.btnhome.IconMarginRight = 0;
            this.btnhome.IconRightVisible = true;
            this.btnhome.IconRightZoom = 0D;
            this.btnhome.IconVisible = true;
            this.btnhome.IconZoom = 60D;
            this.btnhome.IsTab = false;
            this.btnhome.Location = new System.Drawing.Point(0, 124);
            this.btnhome.Name = "btnhome";
            this.btnhome.Normalcolor = System.Drawing.Color.DimGray;
            this.btnhome.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.btnhome.OnHoverTextColor = System.Drawing.Color.White;
            this.btnhome.selected = false;
            this.btnhome.Size = new System.Drawing.Size(241, 48);
            this.btnhome.TabIndex = 3;
            this.btnhome.Text = "    DASHBOARD";
            this.btnhome.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnhome.Textcolor = System.Drawing.Color.White;
            this.btnhome.TextFont = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnhome.Click += new System.EventHandler(this.btnhome_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::spa.Properties.Resources.logo;
            this.pictureBox2.Location = new System.Drawing.Point(29, 17);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(171, 76);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 2;
            this.pictureBox2.TabStop = false;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.btnprintrecipt);
            this.panel4.Controls.Add(this.label7);
            this.panel4.Controls.Add(this.label4);
            this.panel4.Controls.Add(this.label13);
            this.panel4.Controls.Add(this.btnsearchid);
            this.panel4.Controls.Add(this.lblprice);
            this.panel4.Controls.Add(this.label2);
            this.panel4.Controls.Add(this.txtamt);
            this.panel4.Controls.Add(this.label3);
            this.panel4.Controls.Add(this.lblname);
            this.panel4.Controls.Add(this.txtname);
            this.panel4.Location = new System.Drawing.Point(264, 81);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(625, 207);
            this.panel4.TabIndex = 11;
            // 
            // btnprintrecipt
            // 
            this.btnprintrecipt.BackColor = System.Drawing.Color.LightGray;
            this.btnprintrecipt.FlatAppearance.BorderColor = System.Drawing.Color.Green;
            this.btnprintrecipt.FlatAppearance.BorderSize = 5;
            this.btnprintrecipt.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.btnprintrecipt.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Lime;
            this.btnprintrecipt.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnprintrecipt.Location = new System.Drawing.Point(415, 156);
            this.btnprintrecipt.Name = "btnprintrecipt";
            this.btnprintrecipt.Size = new System.Drawing.Size(152, 36);
            this.btnprintrecipt.TabIndex = 21;
            this.btnprintrecipt.Text = "Print Reciept";
            this.btnprintrecipt.UseVisualStyleBackColor = false;
            this.btnprintrecipt.Visible = false;
            this.btnprintrecipt.Click += new System.EventHandler(this.btnsubmit_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(332, 167);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(40, 25);
            this.label7.TabIndex = 26;
            this.label7.Text = ".00";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(218, 168);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(23, 25);
            this.label4.TabIndex = 25;
            this.label4.Text = "$";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(38, 114);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(57, 25);
            this.label13.TabIndex = 27;
            this.label13.Text = "Price";
            // 
            // btnsearchid
            // 
            this.btnsearchid.BackColor = System.Drawing.Color.LightGray;
            this.btnsearchid.FlatAppearance.BorderColor = System.Drawing.Color.Green;
            this.btnsearchid.FlatAppearance.BorderSize = 5;
            this.btnsearchid.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.btnsearchid.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Lime;
            this.btnsearchid.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsearchid.Location = new System.Drawing.Point(380, 50);
            this.btnsearchid.Name = "btnsearchid";
            this.btnsearchid.Size = new System.Drawing.Size(120, 27);
            this.btnsearchid.TabIndex = 22;
            this.btnsearchid.Text = "Search Id";
            this.btnsearchid.UseVisualStyleBackColor = false;
            this.btnsearchid.Click += new System.EventHandler(this.btnsearchname_Click);
            // 
            // lblprice
            // 
            this.lblprice.AutoSize = true;
            this.lblprice.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblprice.Location = new System.Drawing.Point(223, 114);
            this.lblprice.Name = "lblprice";
            this.lblprice.Size = new System.Drawing.Size(64, 25);
            this.lblprice.TabIndex = 24;
            this.lblprice.Text = "Name";
            this.lblprice.Visible = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(31, 168);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(144, 25);
            this.label2.TabIndex = 23;
            this.label2.Text = "Cash Recieved";
            // 
            // txtamt
            // 
            this.txtamt.Location = new System.Drawing.Point(251, 168);
            this.txtamt.Multiline = true;
            this.txtamt.Name = "txtamt";
            this.txtamt.Size = new System.Drawing.Size(73, 27);
            this.txtamt.TabIndex = 22;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(246, 17);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(170, 25);
            this.label3.TabIndex = 6;
            this.label3.Text = "SALES RECEIPT";
            // 
            // lblname
            // 
            this.lblname.AutoSize = true;
            this.lblname.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblname.Location = new System.Drawing.Point(31, 51);
            this.lblname.Name = "lblname";
            this.lblname.Size = new System.Drawing.Size(148, 25);
            this.lblname.TabIndex = 0;
            this.lblname.Text = "Appointment Id";
            // 
            // txtname
            // 
            this.txtname.Location = new System.Drawing.Point(228, 49);
            this.txtname.Multiline = true;
            this.txtname.Name = "txtname";
            this.txtname.Size = new System.Drawing.Size(84, 27);
            this.txtname.TabIndex = 5;
            // 
            // panel5
            // 
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel5.Controls.Add(this.label12);
            this.panel5.Controls.Add(this.label10);
            this.panel5.Controls.Add(this.label9);
            this.panel5.Controls.Add(this.label8);
            this.panel5.Controls.Add(this.label1);
            this.panel5.Controls.Add(this.lblchange);
            this.panel5.Controls.Add(this.label11);
            this.panel5.Controls.Add(this.lblyourcash);
            this.panel5.Controls.Add(this.lblservicedet);
            this.panel5.Controls.Add(this.lblservicenum);
            this.panel5.Controls.Add(this.lblcostof1);
            this.panel5.Controls.Add(this.pictureBox3);
            this.panel5.Controls.Add(this.lblServiceName);
            this.panel5.Controls.Add(this.label6);
            this.panel5.Controls.Add(this.lbldate);
            this.panel5.Controls.Add(this.lbltotcost);
            this.panel5.Controls.Add(this.label5);
            this.panel5.Location = new System.Drawing.Point(264, 81);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(619, 550);
            this.panel5.TabIndex = 12;
            this.panel5.Visible = false;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(537, 3);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(79, 25);
            this.label12.TabIndex = 39;
            this.label12.Text = "Receipt";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(516, 357);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(40, 25);
            this.label10.TabIndex = 38;
            this.label10.Text = ".00";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(516, 311);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(40, 25);
            this.label9.TabIndex = 37;
            this.label9.Text = ".00";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(516, 253);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(40, 25);
            this.label8.TabIndex = 36;
            this.label8.Text = ".00";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(516, 124);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(40, 25);
            this.label1.TabIndex = 35;
            this.label1.Text = ".00";
            // 
            // lblchange
            // 
            this.lblchange.AutoSize = true;
            this.lblchange.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblchange.Location = new System.Drawing.Point(445, 357);
            this.lblchange.Name = "lblchange";
            this.lblchange.Size = new System.Drawing.Size(53, 25);
            this.lblchange.TabIndex = 33;
            this.lblchange.Text = "Cost";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(151, 463);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(290, 50);
            this.label11.TabIndex = 31;
            this.label11.Text = "***Thank you***\r\n***Hope To See You Again***\r\n";
            this.label11.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblyourcash
            // 
            this.lblyourcash.AutoSize = true;
            this.lblyourcash.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblyourcash.Location = new System.Drawing.Point(441, 311);
            this.lblyourcash.Name = "lblyourcash";
            this.lblyourcash.Size = new System.Drawing.Size(53, 25);
            this.lblyourcash.TabIndex = 30;
            this.lblyourcash.Text = "Cost";
            // 
            // lblservicedet
            // 
            this.lblservicedet.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblservicedet.Location = new System.Drawing.Point(31, 168);
            this.lblservicedet.Name = "lblservicedet";
            this.lblservicedet.Size = new System.Drawing.Size(180, 113);
            this.lblservicedet.TabIndex = 29;
            this.lblservicedet.Text = "Details";
            // 
            // lblservicenum
            // 
            this.lblservicenum.AutoSize = true;
            this.lblservicenum.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblservicenum.Location = new System.Drawing.Point(264, 124);
            this.lblservicenum.Name = "lblservicenum";
            this.lblservicenum.Size = new System.Drawing.Size(61, 25);
            this.lblservicenum.TabIndex = 28;
            this.lblservicenum.Text = "AMT";
            // 
            // lblcostof1
            // 
            this.lblcostof1.AutoSize = true;
            this.lblcostof1.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcostof1.Location = new System.Drawing.Point(441, 124);
            this.lblcostof1.Name = "lblcostof1";
            this.lblcostof1.Size = new System.Drawing.Size(53, 25);
            this.lblcostof1.TabIndex = 27;
            this.lblcostof1.Text = "Cost";
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::spa.Properties.Resources.logo;
            this.pictureBox3.Location = new System.Drawing.Point(248, 3);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(103, 37);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 8;
            this.pictureBox3.TabStop = false;
            // 
            // lblServiceName
            // 
            this.lblServiceName.AutoSize = true;
            this.lblServiceName.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblServiceName.Location = new System.Drawing.Point(31, 124);
            this.lblServiceName.Name = "lblServiceName";
            this.lblServiceName.Size = new System.Drawing.Size(78, 25);
            this.lblServiceName.TabIndex = 22;
            this.lblServiceName.Text = "Service";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(31, 357);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(77, 25);
            this.label6.TabIndex = 26;
            this.label6.Text = "Change";
            // 
            // lbldate
            // 
            this.lbldate.AutoSize = true;
            this.lbldate.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbldate.Location = new System.Drawing.Point(445, 51);
            this.lbldate.Name = "lbldate";
            this.lbldate.Size = new System.Drawing.Size(54, 25);
            this.lbldate.TabIndex = 21;
            this.lbldate.Text = "Date";
            // 
            // lbltotcost
            // 
            this.lbltotcost.AutoSize = true;
            this.lbltotcost.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltotcost.Location = new System.Drawing.Point(441, 256);
            this.lbltotcost.Name = "lbltotcost";
            this.lbltotcost.Size = new System.Drawing.Size(57, 25);
            this.lbltotcost.TabIndex = 23;
            this.lbltotcost.Text = "Total";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(31, 311);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(56, 25);
            this.label5.TabIndex = 24;
            this.label5.Text = "Cash";
            // 
            // bunifuDragControl1
            // 
            this.bunifuDragControl1.Fixed = true;
            this.bunifuDragControl1.Horizontal = true;
            this.bunifuDragControl1.TargetControl = this.panel1;
            this.bunifuDragControl1.Vertical = true;
            // 
            // btnprint
            // 
            this.btnprint.BackColor = System.Drawing.Color.LightGray;
            this.btnprint.BackgroundImage = global::spa.Properties.Resources.print;
            this.btnprint.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnprint.FlatAppearance.BorderColor = System.Drawing.Color.Green;
            this.btnprint.FlatAppearance.BorderSize = 5;
            this.btnprint.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.btnprint.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Lime;
            this.btnprint.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnprint.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnprint.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnprint.Location = new System.Drawing.Point(20, 18);
            this.btnprint.Name = "btnprint";
            this.btnprint.Size = new System.Drawing.Size(67, 40);
            this.btnprint.TabIndex = 28;
            this.btnprint.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnprint.UseVisualStyleBackColor = false;
            this.btnprint.Click += new System.EventHandler(this.btnprint_Click);
            // 
            // printDocument1
            // 
            this.printDocument1.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocument1_PrintPage);
            // 
            // printPreviewDialog1
            // 
            this.printPreviewDialog1.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.ClientSize = new System.Drawing.Size(400, 300);
            this.printPreviewDialog1.Document = this.printDocument1;
            this.printPreviewDialog1.Enabled = true;
            this.printPreviewDialog1.Icon = ((System.Drawing.Icon)(resources.GetObject("printPreviewDialog1.Icon")));
            this.printPreviewDialog1.Name = "printPreviewDialog1";
            this.printPreviewDialog1.Visible = false;
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.btnprint);
            this.panel6.Location = new System.Drawing.Point(793, 637);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(90, 61);
            this.panel6.TabIndex = 40;
            // 
            // payment
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(924, 711);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel5);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "payment";
            this.Text = "payment";
            this.Load += new System.EventHandler(this.payment_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.imguserlogin)).EndInit();
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.panel6.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnclose;
        protected System.Windows.Forms.Label lblnameemployee;
        protected System.Windows.Forms.PictureBox imguserlogin;
        private System.Windows.Forms.Panel panel2;
        protected Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton1;
        protected Bunifu.Framework.UI.BunifuFlatButton btnlogout;
        protected Bunifu.Framework.UI.BunifuFlatButton btnrecievepay;
        protected Bunifu.Framework.UI.BunifuFlatButton btnsetappoint;
        protected Bunifu.Framework.UI.BunifuFlatButton btndash;
        protected System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel3;
        protected Bunifu.Framework.UI.BunifuFlatButton btncreatecust;
        protected Bunifu.Framework.UI.BunifuFlatButton btnsignout;
        protected Bunifu.Framework.UI.BunifuFlatButton btnpay;
        protected Bunifu.Framework.UI.BunifuFlatButton btnappoint;
        protected Bunifu.Framework.UI.BunifuFlatButton btnhome;
        protected System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.TextBox txtname;
        private System.Windows.Forms.Label lblname;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lbltotcost;
        private System.Windows.Forms.Label lblServiceName;
        private System.Windows.Forms.Label lbldate;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label lblyourcash;
        private System.Windows.Forms.Label lblservicedet;
        private System.Windows.Forms.Label lblservicenum;
        private System.Windows.Forms.Label lblcostof1;
        protected System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label lblchange;
        private System.Windows.Forms.Button btnprintrecipt;
        private System.Windows.Forms.Label lblprice;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtamt;
        private System.Windows.Forms.Button btnsearchid;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label1;
        private Bunifu.Framework.UI.BunifuDragControl bunifuDragControl1;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button btnprint;
        private System.Drawing.Printing.PrintDocument printDocument1;
        private System.Windows.Forms.PrintPreviewDialog printPreviewDialog1;
        private System.Windows.Forms.Panel panel6;
        protected System.Windows.Forms.Label lblusername;
    }
}