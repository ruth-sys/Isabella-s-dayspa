﻿namespace spa
{
    partial class setappoint
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(setappoint));
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblusername = new System.Windows.Forms.Label();
            this.btnclose = new System.Windows.Forms.Button();
            this.lblnameemployee = new System.Windows.Forms.Label();
            this.imguserlogin = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btncreatecust = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnlogout = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnrecievepay = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnsetappoint = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btndash = new Bunifu.Framework.UI.BunifuFlatButton();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.addappointment = new System.Windows.Forms.Panel();
            this.label16 = new System.Windows.Forms.Label();
            this.txttechname = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.btninvoice = new System.Windows.Forms.Button();
            this.txtemail = new System.Windows.Forms.TextBox();
            this.lblemail = new System.Windows.Forms.Label();
            this.txtamount = new System.Windows.Forms.TextBox();
            this.lblamount = new System.Windows.Forms.Label();
            this.txtdesc = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtsession = new System.Windows.Forms.TextBox();
            this.lbltime = new System.Windows.Forms.Label();
            this.comboboxservicetype = new System.Windows.Forms.ComboBox();
            this.dateTimeappointment = new System.Windows.Forms.DateTimePicker();
            this.lblcost = new System.Windows.Forms.Label();
            this.txtcost = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnset = new System.Windows.Forms.Button();
            this.lblname = new System.Windows.Forms.Label();
            this.txtname = new System.Windows.Forms.TextBox();
            this.comboBoxSingles = new System.Windows.Forms.ComboBox();
            this.comboBoxpackage = new System.Windows.Forms.ComboBox();
            this.panelinvoice = new System.Windows.Forms.Panel();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.lblcontact = new System.Windows.Forms.Label();
            this.lblappoint = new System.Windows.Forms.Label();
            this.lblcustid = new System.Windows.Forms.Label();
            this.lbltodaydate = new System.Windows.Forms.Label();
            this.lblinvoiceid = new System.Windows.Forms.Label();
            this.lbltotal = new System.Windows.Forms.Label();
            this.lblinvoicecost = new System.Windows.Forms.Label();
            this.lblserviceamt = new System.Windows.Forms.Label();
            this.lblinservicename = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.labelap = new System.Windows.Forms.Label();
            this.labelcust = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lblinvoice = new System.Windows.Forms.Label();
            this.labledate = new System.Windows.Forms.Label();
            this.lblinvoiceemail = new System.Windows.Forms.Label();
            this.lblinvoicename = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.lbldescript = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.btnprint = new System.Windows.Forms.Button();
            this.bunifuDragControl1 = new Bunifu.Framework.UI.BunifuDragControl(this.components);
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            this.printPreviewDialog1 = new System.Windows.Forms.PrintPreviewDialog();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.imguserlogin)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.addappointment.SuspendLayout();
            this.panelinvoice.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.DimGray;
            this.panel1.Controls.Add(this.lblusername);
            this.panel1.Controls.Add(this.btnclose);
            this.panel1.Controls.Add(this.lblnameemployee);
            this.panel1.Controls.Add(this.imguserlogin);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1015, 76);
            this.panel1.TabIndex = 1;
            // 
            // lblusername
            // 
            this.lblusername.AutoSize = true;
            this.lblusername.Font = new System.Drawing.Font("Brush Script MT", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblusername.Location = new System.Drawing.Point(89, 42);
            this.lblusername.Name = "lblusername";
            this.lblusername.Size = new System.Drawing.Size(131, 17);
            this.lblusername.TabIndex = 12;
            this.lblusername.Text = "Username of Employee";
            // 
            // btnclose
            // 
            this.btnclose.BackgroundImage = global::spa.Properties.Resources.close_button;
            this.btnclose.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnclose.Location = new System.Drawing.Point(977, 0);
            this.btnclose.Name = "btnclose";
            this.btnclose.Size = new System.Drawing.Size(38, 23);
            this.btnclose.TabIndex = 10;
            this.btnclose.UseVisualStyleBackColor = true;
            this.btnclose.Click += new System.EventHandler(this.btnclose_Click);
            // 
            // lblnameemployee
            // 
            this.lblnameemployee.AutoSize = true;
            this.lblnameemployee.Font = new System.Drawing.Font("Bradley Hand ITC", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblnameemployee.Location = new System.Drawing.Point(87, 12);
            this.lblnameemployee.Name = "lblnameemployee";
            this.lblnameemployee.Size = new System.Drawing.Size(216, 30);
            this.lblnameemployee.TabIndex = 2;
            this.lblnameemployee.Text = "Name of Employee";
            // 
            // imguserlogin
            // 
            this.imguserlogin.Image = global::spa.Properties.Resources.usernamelogin;
            this.imguserlogin.Location = new System.Drawing.Point(29, 12);
            this.imguserlogin.Name = "imguserlogin";
            this.imguserlogin.Size = new System.Drawing.Size(52, 47);
            this.imguserlogin.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.imguserlogin.TabIndex = 1;
            this.imguserlogin.TabStop = false;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.DimGray;
            this.panel2.Controls.Add(this.btncreatecust);
            this.panel2.Controls.Add(this.btnlogout);
            this.panel2.Controls.Add(this.btnrecievepay);
            this.panel2.Controls.Add(this.btnsetappoint);
            this.panel2.Controls.Add(this.btndash);
            this.panel2.Controls.Add(this.pictureBox1);
            this.panel2.Location = new System.Drawing.Point(0, 65);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(249, 496);
            this.panel2.TabIndex = 3;
            // 
            // btncreatecust
            // 
            this.btncreatecust.Activecolor = System.Drawing.Color.DimGray;
            this.btncreatecust.BackColor = System.Drawing.Color.DimGray;
            this.btncreatecust.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btncreatecust.BorderRadius = 0;
            this.btncreatecust.ButtonText = "  CREATE NEW CUSTOMER";
            this.btncreatecust.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btncreatecust.DisabledColor = System.Drawing.Color.Gray;
            this.btncreatecust.Iconcolor = System.Drawing.Color.Transparent;
            this.btncreatecust.Iconimage = global::spa.Properties.Resources.customer;
            this.btncreatecust.Iconimage_right = null;
            this.btncreatecust.Iconimage_right_Selected = null;
            this.btncreatecust.Iconimage_Selected = null;
            this.btncreatecust.IconMarginLeft = 0;
            this.btncreatecust.IconMarginRight = 0;
            this.btncreatecust.IconRightVisible = true;
            this.btncreatecust.IconRightZoom = 0D;
            this.btncreatecust.IconVisible = true;
            this.btncreatecust.IconZoom = 60D;
            this.btncreatecust.IsTab = false;
            this.btncreatecust.Location = new System.Drawing.Point(0, 198);
            this.btncreatecust.Name = "btncreatecust";
            this.btncreatecust.Normalcolor = System.Drawing.Color.DimGray;
            this.btncreatecust.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.btncreatecust.OnHoverTextColor = System.Drawing.Color.White;
            this.btncreatecust.selected = false;
            this.btncreatecust.Size = new System.Drawing.Size(241, 48);
            this.btncreatecust.TabIndex = 7;
            this.btncreatecust.Text = "  CREATE NEW CUSTOMER";
            this.btncreatecust.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btncreatecust.Textcolor = System.Drawing.Color.White;
            this.btncreatecust.TextFont = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncreatecust.Click += new System.EventHandler(this.btncreatecust_Click);
            // 
            // btnlogout
            // 
            this.btnlogout.Activecolor = System.Drawing.Color.DimGray;
            this.btnlogout.BackColor = System.Drawing.Color.DimGray;
            this.btnlogout.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnlogout.BorderRadius = 0;
            this.btnlogout.ButtonText = "";
            this.btnlogout.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnlogout.DisabledColor = System.Drawing.Color.Gray;
            this.btnlogout.Iconcolor = System.Drawing.Color.Transparent;
            this.btnlogout.Iconimage = global::spa.Properties.Resources.logout;
            this.btnlogout.Iconimage_right = null;
            this.btnlogout.Iconimage_right_Selected = null;
            this.btnlogout.Iconimage_Selected = null;
            this.btnlogout.IconMarginLeft = 0;
            this.btnlogout.IconMarginRight = 0;
            this.btnlogout.IconRightVisible = true;
            this.btnlogout.IconRightZoom = 0D;
            this.btnlogout.IconVisible = true;
            this.btnlogout.IconZoom = 60D;
            this.btnlogout.IsTab = false;
            this.btnlogout.Location = new System.Drawing.Point(82, 405);
            this.btnlogout.Name = "btnlogout";
            this.btnlogout.Normalcolor = System.Drawing.Color.DimGray;
            this.btnlogout.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.btnlogout.OnHoverTextColor = System.Drawing.Color.White;
            this.btnlogout.selected = false;
            this.btnlogout.Size = new System.Drawing.Size(48, 48);
            this.btnlogout.TabIndex = 6;
            this.btnlogout.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnlogout.Textcolor = System.Drawing.Color.White;
            this.btnlogout.TextFont = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnlogout.Click += new System.EventHandler(this.btnlogout_Click);
            // 
            // btnrecievepay
            // 
            this.btnrecievepay.Activecolor = System.Drawing.Color.DimGray;
            this.btnrecievepay.BackColor = System.Drawing.Color.DimGray;
            this.btnrecievepay.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnrecievepay.BorderRadius = 0;
            this.btnrecievepay.ButtonText = "  RECIEVE PAYEMENT";
            this.btnrecievepay.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnrecievepay.DisabledColor = System.Drawing.Color.Gray;
            this.btnrecievepay.Iconcolor = System.Drawing.Color.Transparent;
            this.btnrecievepay.Iconimage = global::spa.Properties.Resources.payment;
            this.btnrecievepay.Iconimage_right = null;
            this.btnrecievepay.Iconimage_right_Selected = null;
            this.btnrecievepay.Iconimage_Selected = null;
            this.btnrecievepay.IconMarginLeft = 0;
            this.btnrecievepay.IconMarginRight = 0;
            this.btnrecievepay.IconRightVisible = true;
            this.btnrecievepay.IconRightZoom = 0D;
            this.btnrecievepay.IconVisible = true;
            this.btnrecievepay.IconZoom = 60D;
            this.btnrecievepay.IsTab = false;
            this.btnrecievepay.Location = new System.Drawing.Point(0, 351);
            this.btnrecievepay.Name = "btnrecievepay";
            this.btnrecievepay.Normalcolor = System.Drawing.Color.DimGray;
            this.btnrecievepay.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.btnrecievepay.OnHoverTextColor = System.Drawing.Color.White;
            this.btnrecievepay.selected = false;
            this.btnrecievepay.Size = new System.Drawing.Size(241, 48);
            this.btnrecievepay.TabIndex = 5;
            this.btnrecievepay.Text = "  RECIEVE PAYEMENT";
            this.btnrecievepay.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnrecievepay.Textcolor = System.Drawing.Color.White;
            this.btnrecievepay.TextFont = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnrecievepay.Click += new System.EventHandler(this.btnrecievepay_Click);
            // 
            // btnsetappoint
            // 
            this.btnsetappoint.Activecolor = System.Drawing.Color.Lime;
            this.btnsetappoint.BackColor = System.Drawing.Color.Lime;
            this.btnsetappoint.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnsetappoint.BorderRadius = 0;
            this.btnsetappoint.ButtonText = "  SET APPOINTMENT";
            this.btnsetappoint.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnsetappoint.DisabledColor = System.Drawing.Color.Gray;
            this.btnsetappoint.Iconcolor = System.Drawing.Color.Transparent;
            this.btnsetappoint.Iconimage = global::spa.Properties.Resources.appointment;
            this.btnsetappoint.Iconimage_right = null;
            this.btnsetappoint.Iconimage_right_Selected = null;
            this.btnsetappoint.Iconimage_Selected = null;
            this.btnsetappoint.IconMarginLeft = 0;
            this.btnsetappoint.IconMarginRight = 0;
            this.btnsetappoint.IconRightVisible = true;
            this.btnsetappoint.IconRightZoom = 0D;
            this.btnsetappoint.IconVisible = true;
            this.btnsetappoint.IconZoom = 60D;
            this.btnsetappoint.IsTab = false;
            this.btnsetappoint.Location = new System.Drawing.Point(0, 273);
            this.btnsetappoint.Name = "btnsetappoint";
            this.btnsetappoint.Normalcolor = System.Drawing.Color.Lime;
            this.btnsetappoint.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.btnsetappoint.OnHoverTextColor = System.Drawing.Color.White;
            this.btnsetappoint.selected = true;
            this.btnsetappoint.Size = new System.Drawing.Size(241, 48);
            this.btnsetappoint.TabIndex = 4;
            this.btnsetappoint.Text = "  SET APPOINTMENT";
            this.btnsetappoint.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnsetappoint.Textcolor = System.Drawing.Color.White;
            this.btnsetappoint.TextFont = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsetappoint.Click += new System.EventHandler(this.btnsetappoint_Click);
            // 
            // btndash
            // 
            this.btndash.Activecolor = System.Drawing.Color.DimGray;
            this.btndash.BackColor = System.Drawing.Color.DimGray;
            this.btndash.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btndash.BorderRadius = 0;
            this.btndash.ButtonText = "    DASHBOARD";
            this.btndash.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btndash.DisabledColor = System.Drawing.Color.Gray;
            this.btndash.Iconcolor = System.Drawing.Color.Transparent;
            this.btndash.Iconimage = global::spa.Properties.Resources.dashboard;
            this.btndash.Iconimage_right = null;
            this.btndash.Iconimage_right_Selected = null;
            this.btndash.Iconimage_Selected = null;
            this.btndash.IconMarginLeft = 0;
            this.btndash.IconMarginRight = 0;
            this.btndash.IconRightVisible = true;
            this.btndash.IconRightZoom = 0D;
            this.btndash.IconVisible = true;
            this.btndash.IconZoom = 60D;
            this.btndash.IsTab = false;
            this.btndash.Location = new System.Drawing.Point(0, 124);
            this.btndash.Name = "btndash";
            this.btndash.Normalcolor = System.Drawing.Color.DimGray;
            this.btndash.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.btndash.OnHoverTextColor = System.Drawing.Color.White;
            this.btndash.selected = false;
            this.btndash.Size = new System.Drawing.Size(241, 48);
            this.btndash.TabIndex = 3;
            this.btndash.Text = "    DASHBOARD";
            this.btndash.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btndash.Textcolor = System.Drawing.Color.White;
            this.btndash.TextFont = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btndash.Click += new System.EventHandler(this.btndash_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::spa.Properties.Resources.logo;
            this.pictureBox1.Location = new System.Drawing.Point(29, 17);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(171, 76);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // addappointment
            // 
            this.addappointment.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.addappointment.Controls.Add(this.label16);
            this.addappointment.Controls.Add(this.txttechname);
            this.addappointment.Controls.Add(this.label15);
            this.addappointment.Controls.Add(this.btninvoice);
            this.addappointment.Controls.Add(this.txtemail);
            this.addappointment.Controls.Add(this.lblemail);
            this.addappointment.Controls.Add(this.txtamount);
            this.addappointment.Controls.Add(this.lblamount);
            this.addappointment.Controls.Add(this.txtdesc);
            this.addappointment.Controls.Add(this.label3);
            this.addappointment.Controls.Add(this.txtsession);
            this.addappointment.Controls.Add(this.lbltime);
            this.addappointment.Controls.Add(this.comboboxservicetype);
            this.addappointment.Controls.Add(this.dateTimeappointment);
            this.addappointment.Controls.Add(this.lblcost);
            this.addappointment.Controls.Add(this.txtcost);
            this.addappointment.Controls.Add(this.label2);
            this.addappointment.Controls.Add(this.label1);
            this.addappointment.Controls.Add(this.btnset);
            this.addappointment.Controls.Add(this.lblname);
            this.addappointment.Controls.Add(this.txtname);
            this.addappointment.Controls.Add(this.comboBoxSingles);
            this.addappointment.Controls.Add(this.comboBoxpackage);
            this.addappointment.Location = new System.Drawing.Point(255, 82);
            this.addappointment.Name = "addappointment";
            this.addappointment.Size = new System.Drawing.Size(677, 479);
            this.addappointment.TabIndex = 10;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(82, 270);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(551, 25);
            this.label16.TabIndex = 30;
            this.label16.Text = "*************************************************";
            // 
            // txttechname
            // 
            this.txttechname.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txttechname.Location = new System.Drawing.Point(200, 320);
            this.txttechname.Multiline = true;
            this.txttechname.Name = "txttechname";
            this.txttechname.ReadOnly = true;
            this.txttechname.Size = new System.Drawing.Size(196, 25);
            this.txttechname.TabIndex = 29;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(26, 320);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(158, 25);
            this.label15.TabIndex = 28;
            this.label15.Text = "Head Techinican";
            // 
            // btninvoice
            // 
            this.btninvoice.BackColor = System.Drawing.Color.GreenYellow;
            this.btninvoice.FlatAppearance.BorderColor = System.Drawing.Color.Green;
            this.btninvoice.FlatAppearance.BorderSize = 5;
            this.btninvoice.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.btninvoice.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Lime;
            this.btninvoice.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btninvoice.Location = new System.Drawing.Point(525, 440);
            this.btninvoice.Name = "btninvoice";
            this.btninvoice.Size = new System.Drawing.Size(152, 36);
            this.btninvoice.TabIndex = 26;
            this.btninvoice.Text = "Generate invoice";
            this.btninvoice.UseVisualStyleBackColor = false;
            this.btninvoice.Visible = false;
            this.btninvoice.Click += new System.EventHandler(this.btninvoice_Click);
            // 
            // txtemail
            // 
            this.txtemail.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtemail.Location = new System.Drawing.Point(478, 15);
            this.txtemail.Multiline = true;
            this.txtemail.Name = "txtemail";
            this.txtemail.Size = new System.Drawing.Size(196, 25);
            this.txtemail.TabIndex = 25;
            // 
            // lblemail
            // 
            this.lblemail.AutoSize = true;
            this.lblemail.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblemail.Location = new System.Drawing.Point(362, 15);
            this.lblemail.Name = "lblemail";
            this.lblemail.Size = new System.Drawing.Size(63, 25);
            this.lblemail.TabIndex = 24;
            this.lblemail.Text = "Email";
            // 
            // txtamount
            // 
            this.txtamount.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtamount.Location = new System.Drawing.Point(129, 190);
            this.txtamount.Multiline = true;
            this.txtamount.Name = "txtamount";
            this.txtamount.Size = new System.Drawing.Size(105, 25);
            this.txtamount.TabIndex = 23;
            this.txtamount.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblamount
            // 
            this.lblamount.AutoSize = true;
            this.lblamount.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblamount.Location = new System.Drawing.Point(26, 190);
            this.lblamount.Name = "lblamount";
            this.lblamount.Size = new System.Drawing.Size(82, 25);
            this.lblamount.TabIndex = 22;
            this.lblamount.Text = "Amount";
            // 
            // txtdesc
            // 
            this.txtdesc.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtdesc.Location = new System.Drawing.Point(478, 138);
            this.txtdesc.Multiline = true;
            this.txtdesc.Name = "txtdesc";
            this.txtdesc.ReadOnly = true;
            this.txtdesc.Size = new System.Drawing.Size(196, 91);
            this.txtdesc.TabIndex = 21;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(358, 138);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(107, 25);
            this.label3.TabIndex = 20;
            this.label3.Text = "Desciption";
            // 
            // txtsession
            // 
            this.txtsession.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtsession.Location = new System.Drawing.Point(478, 68);
            this.txtsession.Multiline = true;
            this.txtsession.Name = "txtsession";
            this.txtsession.ReadOnly = true;
            this.txtsession.Size = new System.Drawing.Size(196, 25);
            this.txtsession.TabIndex = 19;
            // 
            // lbltime
            // 
            this.lbltime.AutoSize = true;
            this.lbltime.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltime.Location = new System.Drawing.Point(362, 68);
            this.lbltime.Name = "lbltime";
            this.lbltime.Size = new System.Drawing.Size(57, 25);
            this.lbltime.TabIndex = 18;
            this.lbltime.Text = "Time";
            // 
            // comboboxservicetype
            // 
            this.comboboxservicetype.BackColor = System.Drawing.Color.White;
            this.comboboxservicetype.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboboxservicetype.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboboxservicetype.FormattingEnabled = true;
            this.comboboxservicetype.Items.AddRange(new object[] {
            "Packages",
            "Singles"});
            this.comboboxservicetype.Location = new System.Drawing.Point(129, 66);
            this.comboboxservicetype.Name = "comboboxservicetype";
            this.comboboxservicetype.Size = new System.Drawing.Size(186, 27);
            this.comboboxservicetype.TabIndex = 15;
            this.comboboxservicetype.SelectedIndexChanged += new System.EventHandler(this.comboboxservicetype_SelectedIndexChanged);
            // 
            // dateTimeappointment
            // 
            this.dateTimeappointment.CalendarMonthBackground = System.Drawing.Color.White;
            this.dateTimeappointment.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimeappointment.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.dateTimeappointment.Location = new System.Drawing.Point(298, 240);
            this.dateTimeappointment.Name = "dateTimeappointment";
            this.dateTimeappointment.Size = new System.Drawing.Size(127, 26);
            this.dateTimeappointment.TabIndex = 14;
            this.dateTimeappointment.Value = new System.DateTime(2020, 3, 21, 23, 18, 17, 0);
            // 
            // lblcost
            // 
            this.lblcost.AutoSize = true;
            this.lblcost.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcost.Location = new System.Drawing.Point(26, 138);
            this.lblcost.Name = "lblcost";
            this.lblcost.Size = new System.Drawing.Size(53, 25);
            this.lblcost.TabIndex = 13;
            this.lblcost.Text = "Cost";
            // 
            // txtcost
            // 
            this.txtcost.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcost.Location = new System.Drawing.Point(129, 136);
            this.txtcost.Multiline = true;
            this.txtcost.Name = "txtcost";
            this.txtcost.ReadOnly = true;
            this.txtcost.Size = new System.Drawing.Size(186, 25);
            this.txtcost.TabIndex = 12;
            this.txtcost.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(26, 68);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(78, 25);
            this.label2.TabIndex = 10;
            this.label2.Text = "Service";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(21, 244);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(196, 25);
            this.label1.TabIndex = 9;
            this.label1.Text = "Date of Appointment";
            // 
            // btnset
            // 
            this.btnset.BackColor = System.Drawing.Color.GreenYellow;
            this.btnset.FlatAppearance.BorderColor = System.Drawing.Color.Green;
            this.btnset.FlatAppearance.BorderSize = 5;
            this.btnset.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.btnset.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Lime;
            this.btnset.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnset.Location = new System.Drawing.Point(525, 440);
            this.btnset.Name = "btnset";
            this.btnset.Size = new System.Drawing.Size(152, 36);
            this.btnset.TabIndex = 4;
            this.btnset.Text = "Set Appointment";
            this.btnset.UseVisualStyleBackColor = false;
            this.btnset.Click += new System.EventHandler(this.btnset_Click);
            // 
            // lblname
            // 
            this.lblname.AutoSize = true;
            this.lblname.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblname.Location = new System.Drawing.Point(26, 15);
            this.lblname.Name = "lblname";
            this.lblname.Size = new System.Drawing.Size(64, 25);
            this.lblname.TabIndex = 0;
            this.lblname.Text = "Name";
            // 
            // txtname
            // 
            this.txtname.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtname.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtname.Location = new System.Drawing.Point(129, 15);
            this.txtname.Multiline = true;
            this.txtname.Name = "txtname";
            this.txtname.ScrollBars = System.Windows.Forms.ScrollBars.Horizontal;
            this.txtname.Size = new System.Drawing.Size(186, 25);
            this.txtname.TabIndex = 5;
            // 
            // comboBoxSingles
            // 
            this.comboBoxSingles.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxSingles.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxSingles.FormattingEnabled = true;
            this.comboBoxSingles.Items.AddRange(new object[] {
            "Haircut",
            "Pedicure",
            "Face Dextox",
            "Hair wash"});
            this.comboBoxSingles.Location = new System.Drawing.Point(129, 99);
            this.comboBoxSingles.Name = "comboBoxSingles";
            this.comboBoxSingles.Size = new System.Drawing.Size(186, 27);
            this.comboBoxSingles.TabIndex = 17;
            this.comboBoxSingles.Visible = false;
            this.comboBoxSingles.SelectedIndexChanged += new System.EventHandler(this.comboBoxSingles_SelectedIndexChanged);
            // 
            // comboBoxpackage
            // 
            this.comboBoxpackage.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxpackage.FormattingEnabled = true;
            this.comboBoxpackage.Items.AddRange(new object[] {
            "Men Shave",
            "Women Facial",
            "PediMani Combo",
            "Body Treatment Combo"});
            this.comboBoxpackage.Location = new System.Drawing.Point(129, 99);
            this.comboBoxpackage.Name = "comboBoxpackage";
            this.comboBoxpackage.Size = new System.Drawing.Size(186, 27);
            this.comboBoxpackage.TabIndex = 16;
            this.comboBoxpackage.Visible = false;
            this.comboBoxpackage.SelectedIndexChanged += new System.EventHandler(this.comboBoxpackage_SelectedIndexChanged);
            // 
            // panelinvoice
            // 
            this.panelinvoice.AutoSize = true;
            this.panelinvoice.BackColor = System.Drawing.Color.White;
            this.panelinvoice.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelinvoice.Controls.Add(this.label14);
            this.panelinvoice.Controls.Add(this.label13);
            this.panelinvoice.Controls.Add(this.label12);
            this.panelinvoice.Controls.Add(this.label11);
            this.panelinvoice.Controls.Add(this.lblcontact);
            this.panelinvoice.Controls.Add(this.lblappoint);
            this.panelinvoice.Controls.Add(this.lblcustid);
            this.panelinvoice.Controls.Add(this.lbltodaydate);
            this.panelinvoice.Controls.Add(this.lblinvoiceid);
            this.panelinvoice.Controls.Add(this.lbltotal);
            this.panelinvoice.Controls.Add(this.lblinvoicecost);
            this.panelinvoice.Controls.Add(this.lblserviceamt);
            this.panelinvoice.Controls.Add(this.lblinservicename);
            this.panelinvoice.Controls.Add(this.label10);
            this.panelinvoice.Controls.Add(this.label9);
            this.panelinvoice.Controls.Add(this.label8);
            this.panelinvoice.Controls.Add(this.label6);
            this.panelinvoice.Controls.Add(this.label5);
            this.panelinvoice.Controls.Add(this.label7);
            this.panelinvoice.Controls.Add(this.labelap);
            this.panelinvoice.Controls.Add(this.labelcust);
            this.panelinvoice.Controls.Add(this.label4);
            this.panelinvoice.Controls.Add(this.lblinvoice);
            this.panelinvoice.Controls.Add(this.labledate);
            this.panelinvoice.Controls.Add(this.lblinvoiceemail);
            this.panelinvoice.Controls.Add(this.lblinvoicename);
            this.panelinvoice.Controls.Add(this.pictureBox2);
            this.panelinvoice.Controls.Add(this.lbldescript);
            this.panelinvoice.Location = new System.Drawing.Point(255, 82);
            this.panelinvoice.Name = "panelinvoice";
            this.panelinvoice.Size = new System.Drawing.Size(761, 383);
            this.panelinvoice.TabIndex = 12;
            this.panelinvoice.Visible = false;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(455, 249);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(17, 19);
            this.label14.TabIndex = 41;
            this.label14.Text = "$";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(600, 249);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(17, 19);
            this.label13.TabIndex = 40;
            this.label13.Text = "$";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(672, 249);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(29, 19);
            this.label12.TabIndex = 39;
            this.label12.Text = ".00";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(519, 249);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(29, 19);
            this.label11.TabIndex = 38;
            this.label11.Text = ".00";
            // 
            // lblcontact
            // 
            this.lblcontact.AutoSize = true;
            this.lblcontact.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcontact.Location = new System.Drawing.Point(150, 134);
            this.lblcontact.Name = "lblcontact";
            this.lblcontact.Size = new System.Drawing.Size(99, 19);
            this.lblcontact.TabIndex = 36;
            this.lblcontact.Text = "000-000-0000";
            // 
            // lblappoint
            // 
            this.lblappoint.AutoSize = true;
            this.lblappoint.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblappoint.Location = new System.Drawing.Point(600, 137);
            this.lblappoint.Name = "lblappoint";
            this.lblappoint.Size = new System.Drawing.Size(41, 19);
            this.lblappoint.TabIndex = 35;
            this.lblappoint.Text = "0000";
            // 
            // lblcustid
            // 
            this.lblcustid.AutoSize = true;
            this.lblcustid.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcustid.Location = new System.Drawing.Point(455, 135);
            this.lblcustid.Name = "lblcustid";
            this.lblcustid.Size = new System.Drawing.Size(41, 19);
            this.lblcustid.TabIndex = 34;
            this.lblcustid.Text = "0000";
            // 
            // lbltodaydate
            // 
            this.lbltodaydate.AutoSize = true;
            this.lbltodaydate.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltodaydate.Location = new System.Drawing.Point(588, 70);
            this.lbltodaydate.Name = "lbltodaydate";
            this.lbltodaydate.Size = new System.Drawing.Size(85, 19);
            this.lbltodaydate.TabIndex = 33;
            this.lbltodaydate.Text = "mm/dd/yyyy";
            // 
            // lblinvoiceid
            // 
            this.lblinvoiceid.AutoSize = true;
            this.lblinvoiceid.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblinvoiceid.Location = new System.Drawing.Point(455, 73);
            this.lblinvoiceid.Name = "lblinvoiceid";
            this.lblinvoiceid.Size = new System.Drawing.Size(33, 19);
            this.lblinvoiceid.TabIndex = 32;
            this.lblinvoiceid.Text = "000";
            // 
            // lbltotal
            // 
            this.lbltotal.AutoSize = true;
            this.lbltotal.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltotal.Location = new System.Drawing.Point(623, 249);
            this.lbltotal.Name = "lbltotal";
            this.lbltotal.Size = new System.Drawing.Size(25, 19);
            this.lbltotal.TabIndex = 31;
            this.lbltotal.Text = "00";
            // 
            // lblinvoicecost
            // 
            this.lblinvoicecost.AutoSize = true;
            this.lblinvoicecost.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblinvoicecost.Location = new System.Drawing.Point(473, 249);
            this.lblinvoicecost.Name = "lblinvoicecost";
            this.lblinvoicecost.Size = new System.Drawing.Size(25, 19);
            this.lblinvoicecost.TabIndex = 30;
            this.lblinvoicecost.Text = "00";
            // 
            // lblserviceamt
            // 
            this.lblserviceamt.AutoSize = true;
            this.lblserviceamt.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblserviceamt.Location = new System.Drawing.Point(419, 249);
            this.lblserviceamt.Name = "lblserviceamt";
            this.lblserviceamt.Size = new System.Drawing.Size(17, 19);
            this.lblserviceamt.TabIndex = 29;
            this.lblserviceamt.Text = "1";
            // 
            // lblinservicename
            // 
            this.lblinservicename.AutoSize = true;
            this.lblinservicename.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblinservicename.Location = new System.Drawing.Point(7, 249);
            this.lblinservicename.Name = "lblinservicename";
            this.lblinservicename.Size = new System.Drawing.Size(54, 19);
            this.lblinservicename.TabIndex = 27;
            this.lblinservicename.Text = "service";
            // 
            // label10
            // 
            this.label10.BackColor = System.Drawing.Color.Blue;
            this.label10.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(168, 217);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(244, 19);
            this.label10.TabIndex = 26;
            this.label10.Text = "Description";
            // 
            // label9
            // 
            this.label9.BackColor = System.Drawing.Color.Blue;
            this.label9.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(3, 217);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(166, 19);
            this.label9.TabIndex = 25;
            this.label9.Text = "Service Name";
            // 
            // label8
            // 
            this.label8.BackColor = System.Drawing.Color.Blue;
            this.label8.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(588, 217);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(156, 19);
            this.label8.TabIndex = 24;
            this.label8.Text = "Total Cost";
            // 
            // label6
            // 
            this.label6.BackColor = System.Drawing.Color.Blue;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(461, 217);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(129, 19);
            this.label6.TabIndex = 23;
            this.label6.Text = "Cost";
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.Color.Blue;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(409, 217);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(55, 19);
            this.label5.TabIndex = 22;
            this.label5.Text = "Amt";
            // 
            // label7
            // 
            this.label7.BackColor = System.Drawing.Color.Blue;
            this.label7.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(3, 106);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(252, 19);
            this.label7.TabIndex = 21;
            this.label7.Text = "Bill To";
            // 
            // labelap
            // 
            this.labelap.BackColor = System.Drawing.Color.Blue;
            this.labelap.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelap.Location = new System.Drawing.Point(580, 101);
            this.labelap.Name = "labelap";
            this.labelap.Size = new System.Drawing.Size(156, 19);
            this.labelap.TabIndex = 20;
            this.labelap.Text = "Appointment Id";
            // 
            // labelcust
            // 
            this.labelcust.BackColor = System.Drawing.Color.Blue;
            this.labelcust.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelcust.Location = new System.Drawing.Point(434, 101);
            this.labelcust.Name = "labelcust";
            this.labelcust.Size = new System.Drawing.Size(156, 19);
            this.labelcust.TabIndex = 19;
            this.labelcust.Text = "Customer ID";
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.Color.Blue;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(434, 45);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(156, 19);
            this.label4.TabIndex = 18;
            this.label4.Text = "Invoice No.";
            // 
            // lblinvoice
            // 
            this.lblinvoice.AutoSize = true;
            this.lblinvoice.Font = new System.Drawing.Font("Times New Roman", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblinvoice.ForeColor = System.Drawing.Color.Red;
            this.lblinvoice.Location = new System.Drawing.Point(640, 0);
            this.lblinvoice.Name = "lblinvoice";
            this.lblinvoice.Size = new System.Drawing.Size(116, 26);
            this.lblinvoice.TabIndex = 16;
            this.lblinvoice.Text = "INVOICE";
            // 
            // labledate
            // 
            this.labledate.BackColor = System.Drawing.Color.Blue;
            this.labledate.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labledate.Location = new System.Drawing.Point(588, 45);
            this.labledate.Name = "labledate";
            this.labledate.Size = new System.Drawing.Size(148, 19);
            this.labledate.TabIndex = 11;
            this.labledate.Text = "Date ";
            // 
            // lblinvoiceemail
            // 
            this.lblinvoiceemail.AutoSize = true;
            this.lblinvoiceemail.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblinvoiceemail.Location = new System.Drawing.Point(5, 162);
            this.lblinvoiceemail.Name = "lblinvoiceemail";
            this.lblinvoiceemail.Size = new System.Drawing.Size(47, 19);
            this.lblinvoiceemail.TabIndex = 10;
            this.lblinvoiceemail.Text = "Email";
            // 
            // lblinvoicename
            // 
            this.lblinvoicename.AutoSize = true;
            this.lblinvoicename.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblinvoicename.Location = new System.Drawing.Point(3, 135);
            this.lblinvoicename.Name = "lblinvoicename";
            this.lblinvoicename.Size = new System.Drawing.Size(51, 19);
            this.lblinvoicename.TabIndex = 9;
            this.lblinvoicename.Text = "Name ";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::spa.Properties.Resources.logo;
            this.pictureBox2.Location = new System.Drawing.Point(-1, 0);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(160, 76);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 8;
            this.pictureBox2.TabStop = false;
            // 
            // lbldescript
            // 
            this.lbldescript.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbldescript.Location = new System.Drawing.Point(168, 249);
            this.lbldescript.Name = "lbldescript";
            this.lbldescript.Size = new System.Drawing.Size(227, 132);
            this.lbldescript.TabIndex = 28;
            this.lbldescript.Text = "Description";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.White;
            this.panel3.Controls.Add(this.btnprint);
            this.panel3.Location = new System.Drawing.Point(252, 477);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(760, 72);
            this.panel3.TabIndex = 31;
            this.panel3.Visible = false;
            this.panel3.Paint += new System.Windows.Forms.PaintEventHandler(this.panel3_Paint);
            // 
            // btnprint
            // 
            this.btnprint.BackColor = System.Drawing.Color.Lime;
            this.btnprint.BackgroundImage = global::spa.Properties.Resources.print;
            this.btnprint.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnprint.FlatAppearance.BorderColor = System.Drawing.Color.Green;
            this.btnprint.FlatAppearance.BorderSize = 5;
            this.btnprint.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.btnprint.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Lime;
            this.btnprint.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnprint.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnprint.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnprint.Location = new System.Drawing.Point(657, 16);
            this.btnprint.Name = "btnprint";
            this.btnprint.Size = new System.Drawing.Size(88, 57);
            this.btnprint.TabIndex = 27;
            this.btnprint.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnprint.UseVisualStyleBackColor = false;
            this.btnprint.Click += new System.EventHandler(this.btnprint_Click);
            // 
            // bunifuDragControl1
            // 
            this.bunifuDragControl1.Fixed = true;
            this.bunifuDragControl1.Horizontal = true;
            this.bunifuDragControl1.TargetControl = this.panel1;
            this.bunifuDragControl1.Vertical = true;
            // 
            // printDocument1
            // 
            this.printDocument1.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocument1_PrintPage);
            // 
            // printPreviewDialog1
            // 
            this.printPreviewDialog1.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.ClientSize = new System.Drawing.Size(400, 300);
            this.printPreviewDialog1.Document = this.printDocument1;
            this.printPreviewDialog1.Enabled = true;
            this.printPreviewDialog1.Icon = ((System.Drawing.Icon)(resources.GetObject("printPreviewDialog1.Icon")));
            this.printPreviewDialog1.Name = "printPreviewDialog1";
            this.printPreviewDialog1.Visible = false;
            // 
            // setappoint
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.Violet;
            this.ClientSize = new System.Drawing.Size(1015, 561);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panelinvoice);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.addappointment);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "setappoint";
            this.Text = "setappoint";
            this.Load += new System.EventHandler(this.setappoint_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.imguserlogin)).EndInit();
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.addappointment.ResumeLayout(false);
            this.addappointment.PerformLayout();
            this.panelinvoice.ResumeLayout(false);
            this.panelinvoice.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel3.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnclose;
        protected System.Windows.Forms.Label lblnameemployee;
        protected System.Windows.Forms.PictureBox imguserlogin;
        private System.Windows.Forms.Panel panel2;
        protected Bunifu.Framework.UI.BunifuFlatButton btncreatecust;
        protected Bunifu.Framework.UI.BunifuFlatButton btnlogout;
        protected Bunifu.Framework.UI.BunifuFlatButton btnrecievepay;
        protected Bunifu.Framework.UI.BunifuFlatButton btnsetappoint;
        protected Bunifu.Framework.UI.BunifuFlatButton btndash;
        protected System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel addappointment;
        private System.Windows.Forms.DateTimePicker dateTimeappointment;
        private System.Windows.Forms.Label lblcost;
        private System.Windows.Forms.TextBox txtcost;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnset;
        private System.Windows.Forms.Label lblname;
        private System.Windows.Forms.TextBox txtname;
        private System.Windows.Forms.ComboBox comboboxservicetype;
        private Bunifu.Framework.UI.BunifuDragControl bunifuDragControl1;
        private System.Windows.Forms.ComboBox comboBoxpackage;
        private System.Windows.Forms.ComboBox comboBoxSingles;
        private System.Windows.Forms.Label lbltime;
        private System.Windows.Forms.TextBox txtsession;
        private System.Windows.Forms.TextBox txtdesc;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtamount;
        private System.Windows.Forms.Label lblamount;
        private System.Windows.Forms.TextBox txtemail;
        private System.Windows.Forms.Label lblemail;
        private System.Windows.Forms.Panel panelinvoice;
        private System.Windows.Forms.Button btninvoice;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label labelap;
        private System.Windows.Forms.Label labelcust;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblinvoice;
        private System.Windows.Forms.Label labledate;
        private System.Windows.Forms.Label lblinvoiceemail;
        private System.Windows.Forms.Label lblinvoicename;
        protected System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label lblappoint;
        private System.Windows.Forms.Label lblcustid;
        private System.Windows.Forms.Label lbltodaydate;
        private System.Windows.Forms.Label lblinvoiceid;
        private System.Windows.Forms.Label lbltotal;
        private System.Windows.Forms.Label lblinvoicecost;
        private System.Windows.Forms.Label lblserviceamt;
        private System.Windows.Forms.Label lbldescript;
        private System.Windows.Forms.Label lblinservicename;
        private System.Windows.Forms.Label lblcontact;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txttechname;
        private System.Windows.Forms.Label label15;
        private System.Drawing.Printing.PrintDocument printDocument1;
        private System.Windows.Forms.PrintPreviewDialog printPreviewDialog1;
        private System.Windows.Forms.Button btnprint;
        private System.Windows.Forms.Panel panel3;
        protected System.Windows.Forms.Label lblusername;
    }
}