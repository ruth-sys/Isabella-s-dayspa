﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace spa
{

    public partial class Allinvoices : Form
    {
        SqlConnection sqlConnection = new SqlConnection(@"Data Source=LAPTOP-1TTNHUIS\SQLEXPRESS;Initial Catalog=spamanagement;Integrated Security=True;Pooling=False");

        public Allinvoices()
        {
            InitializeComponent();
        }

        private void Allinvoices_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'spamanagementDataSet4.invoice' table. You can move, or remove it, as needed.
            this.invoiceTableAdapter.Fill(this.spamanagementDataSet4.invoice);
            lblnameemployee.Text = Employees.name;
            lblusername.Text = Employees.uname;
            

        }


        private void btnsearch_Click(object sender, EventArgs e)
        {
            try
            {
                this.invoiceTableAdapter.FillBy(this.spamanagementDataSet4.invoice, (txtsearch.Text.ToString()));
                button1.Show();

            }
            catch
            {
                MessageBox.Show("Please Enter Appointment Id", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Refresh();
                button1.Show();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //dataGridView2.Hide();
            this.invoiceTableAdapter.Fill(this.spamanagementDataSet4.invoice);
            this.button1.Hide();
        }

        private void btngoback_Click(object sender, EventArgs e)
        {
            this.Hide();
            homeface homeface = new homeface();
            homeface.Show();
        }

       

       

        private void btnclose_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are You Sure You Want To Close The Application", "Message", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning) == DialogResult.OK)
            {
                Application.Exit();
            }
            else
            {
                this.Show();
            }
        }

        private void fillByToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.invoiceTableAdapter.FillBy(this.spamanagementDataSet4.invoice, txtsearch.Text.ToString());
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
