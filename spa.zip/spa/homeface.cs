﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace spa
{
    public partial class homeface : Form
    {
        public homeface()
        {
            InitializeComponent();
        }

        private void homeface_Load(object sender, EventArgs e)
        {
            lblnameemployee.Text = Employees.name;
            lblusername.Text = Employees.uname;
        }

        
        private void btnclose_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are You Sure You Want To Close The Application", "Message", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning) == DialogResult.OK)
            {
                Application.Exit();
            }
            else
            {
                this.Show();
            }
        }

        private void btndash_Click(object sender, EventArgs e)
        {
            this.Refresh();
        }

        private void btncreatecust_Click(object sender, EventArgs e)
        {
            this.Hide();
            createcust createcust = new createcust();
            createcust.Show();
        }

        private void btnsetappoint_Click(object sender, EventArgs e)
        {
            this.Hide();
            setappoint setappoint = new setappoint();
            setappoint.Show();
        }

        private void btnrecievepay_Click(object sender, EventArgs e)
        {
            this.Hide();
            payment payment = new payment();
            payment.Show();
        }

        private void btnlogout_Click(object sender, EventArgs e)
        {
            this.Hide();
            login login = new login();
            login.Show();
        }

        

        private void linkLabelcustomer_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            allcustomer allcustomer = new allcustomer();
            allcustomer.Show();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            this.Hide();
            allcustomer allcustomer = new allcustomer();
            allcustomer.Show();
        }

        private void linkLabel3_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            Appdetails appdetails = new Appdetails();
            appdetails.Show();
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            this.Hide();
            Appdetails appdetails = new Appdetails();
            appdetails.Show();

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            Allinvoices allinvoices = new Allinvoices();
            allinvoices.Show();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Allinvoices allinvoices = new Allinvoices();
            allinvoices.Show();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Hide();
            servicedet servicedet = new servicedet();
            servicedet.Show();
        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            servicedet servicedet = new servicedet();
            servicedet.Show();
        }
    }
}
