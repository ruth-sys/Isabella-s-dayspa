﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Drawing.Printing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace spa
{
    public partial class payment : Form
    {
        SqlConnection sqlConnection = new SqlConnection(@"Data Source=LAPTOP-1TTNHUIS\SQLEXPRESS;Initial Catalog=spamanagement;Integrated Security=True;Pooling=False");
        public payment()
        {
            InitializeComponent();
        }

        private void payment_Load(object sender, EventArgs e)
        {
            lblnameemployee.Text = Employees.name;
            lblusername.Text = Employees.uname;

        }

        private void btnhome_Click(object sender, EventArgs e)
        {
            this.Hide();
            homeface homeface = new homeface();
            homeface.Show();
        }

        private void btncreatecust_Click(object sender, EventArgs e)
        {
            this.Hide();
            createcust createcust = new createcust();
            createcust.Show();
        }

        private void btnappoint_Click(object sender, EventArgs e)
        {
            this.Hide();
            setappoint setappoint = new setappoint();
            setappoint.Show();
        }

        private void btnpay_Click(object sender, EventArgs e)
        {
            this.Refresh();
        }

        private void btnsignout_Click(object sender, EventArgs e)
        {
            this.Hide();
            login login = new login();
            login.Show();
        }

        private void btnsearchname_Click(object sender, EventArgs e)
        {
            try
            {
                sqlConnection.Open();
                SqlCommand com = sqlConnection.CreateCommand();
                com.CommandType = CommandType.Text;
                com.CommandText = "select * from invoice where appointmentid = '"+ txtname.Text+"' ";
                SqlDataReader reader = com.ExecuteReader();

                if (reader.Read())
                {
                    lblprice.Text = reader["total"].ToString();
                    lblprice.Show();
                    btnprintrecipt.Show();

                }
                else
                {
                    MessageBox.Show("Customer does not exist");
                    this.Hide();
                    payment payment = new payment();
                    payment.Show();

                }
            }
            catch
            {
                sqlConnection.Close();
                MessageBox.Show("Application error");
            }
        }

        private void btnsubmit_Click(object sender, EventArgs e)
        {
            sqlConnection.Close();
            sqlConnection.Open();
            SqlCommand cmd = sqlConnection.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "insert into receipt (custmon, appointmentid) values ('" + Convert.ToInt32(txtamt.Text) + "', '"+txtname.Text+"')";
            cmd.ExecuteScalar();

            try
            {
                SqlCommand commd = sqlConnection.CreateCommand();
                commd.CommandType = CommandType.Text;
                commd.CommandText = "select appointmentid, Date, service, amount, cost, total, description, custmon, change from payinfo where appointmentid =  '"+txtname.Text+"' ";
                SqlDataReader data = commd.ExecuteReader();
                if (data.Read())
                {
                    lbldate.Text = data["Date"].ToString();
                    lblServiceName.Text = data["service"].ToString();
                    lblservicenum.Text = data["amount"].ToString();
                    lblcostof1.Text = data["cost"].ToString();
                    lbltotcost.Text = data["total"].ToString();
                    lblservicedet.Text = data["description"].ToString();
                    lblyourcash.Text = data["custmon"].ToString();
                    lblchange.Text = data["change"].ToString();
                    panel4.Hide();
                    panel5.Show();
                    
                }
                else
                {
                    MessageBox.Show("Invaild entry");
                    payment payment = new payment();
                    payment.Show();
                }


            }
            catch
            {
                MessageBox.Show("Application Error");
                payment payment = new payment();
                payment.Show();
            }
        }

        
        private void btnclose_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are You Sure You Want To Close The Application", "Message", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning) == DialogResult.OK)
            {
                Application.Exit();
            }
            else
            {
                this.Show();
            }
        }

        private void btnprint_Click(object sender, EventArgs e)
        {
            Print(this.panel5);
            this.Hide();
            payment payment = new payment();
            payment.Show();
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            Rectangle pagearea = e.PageBounds;
            e.Graphics.DrawImage(bmp, (pagearea.Width / 2) - (this.panel5.Width / 2), this.panel5.Location.Y);
        }
        public void getprintarea(Panel panel)
        {
            bmp = new Bitmap(panel.Width, panel.Height);
            panel.DrawToBitmap(bmp, new Rectangle(0, 0, panel.Width, panel.Height));
        }
        Bitmap bmp;
        public void Print(Panel panel)
        {
            PrinterSettings pd = new PrinterSettings();
            panel5 = panel;
            getprintarea(panel);
            printPreviewDialog1.Document = printDocument1;
            printDocument1.PrintPage += new PrintPageEventHandler(printDocument1_PrintPage);
            printPreviewDialog1.ShowDialog();


        }
    }
}
