﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace spa
{
    public partial class servicedet : Form
    {
        SqlConnection sqlConnection = new SqlConnection(@"Data Source=LAPTOP-1TTNHUIS\SQLEXPRESS;Initial Catalog=spamanagement;Integrated Security=True;Pooling=False");

        public servicedet()
        {
            InitializeComponent();
        }

        private void servicedet_Load(object sender, EventArgs e)
        {
            lblnameemployee.Text = Employees.name;
            lblusername.Text = Employees.uname;
            // TODO: This line of code loads data into the 'spamanagementDataSet2.appointment' table. You can move, or remove it, as needed.
            this.appointmentTableAdapter.Fill(this.spamanagementDataSet2.appointment);
            

        }

        private void btnclose_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are You Sure You Want To Close The Application", "Message", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning) == DialogResult.OK)
            {
                Application.Exit();
            }
            else
            {
                this.Show();
            }
        }

        private void btnsearch_Click(object sender, EventArgs e)
        {
            try
            {
                this.appointmentTableAdapter.FillBy(this.spamanagementDataSet2.appointment, txtsearch.Text);
                btnservicedetails.Show();

            }
            catch
            {
                MessageBox.Show("Please Enter Appointment Id", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Refresh();
                btnservicedetails.Show();
            }
        }

        private void btnservicedetails_Click(object sender, EventArgs e)
        {
            this.appointmentTableAdapter.Fill(this.spamanagementDataSet2.appointment);
            this.btnservicedetails.Hide();
        }

        private void btngoback_Click(object sender, EventArgs e)
        {
            this.Hide();
            homeface homeface = new homeface();
            homeface.Show();
        }

        private void fillByToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.appointmentTableAdapter.FillBy(this.spamanagementDataSet2.appointment, technameToolStripTextBox.Text);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

       
    }
}
