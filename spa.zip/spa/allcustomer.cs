﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace spa
{
    public partial class allcustomer : Form
    {
        SqlConnection sqlConnection = new SqlConnection(@"Data Source=LAPTOP-1TTNHUIS\SQLEXPRESS;Initial Catalog=spamanagement;Integrated Security=True;Pooling=False");

        public allcustomer()
        {
            InitializeComponent();
        }

        private void allcustomer_Load(object sender, EventArgs e)
        {
            lblnameemployee.Text = Employees.name;
            lblusername.Text = Employees.uname;
            // TODO: This line of code loads data into the 'spamanagementDataSet.customer' table. You can move, or remove it, as needed.
            this.customerTableAdapter.Fill(this.spamanagementDataSet.customer);

        }

        private void btnclose_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are You Sure You Want To Close The Application", "Message", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning) == DialogResult.OK)
            {
                Application.Exit();
            }
            else
            {
                this.Show();
            }
        }

        private void txtsearch_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void btnsearch_Click(object sender, EventArgs e)
        {
            try
            {
                this.customerTableAdapter.FillBy(this.spamanagementDataSet.customer, txtsearch.Text);
                button1.Show();

            }
            catch
            {
                MessageBox.Show("Please Enter Appointment Id", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Refresh();
                button1.Show();
            }



        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.customerTableAdapter.Fill(this.spamanagementDataSet.customer);
            this.button1.Hide();
        }

        private void btngoback_Click(object sender, EventArgs e)
        {
            this.Hide();
            homeface homeface = new homeface();
            homeface.Show();
        }
        

        private void dataGridView1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Delete)
            {
                if (MessageBox.Show("Delete Record ?", "Message", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    customerBindingSource.RemoveCurrent();
                }
                else
                {
                    dataGridView1.Show();
                }
            }
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            try
            {
                if (MessageBox.Show("You Are About to Make A Change", "Message", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning) == DialogResult.OK)
                {
                  customerBindingSource.EndEdit();
                  customerTableAdapter.Update(this.spamanagementDataSet.customer);
                }
                else
                {
                    this.customerTableAdapter.Fill(this.spamanagementDataSet.customer);

                }



            }
            catch
            {
                MessageBox.Show("An error occured");
            }
            Cursor.Current = Cursors.Default;

        }
    }
}
