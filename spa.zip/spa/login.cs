﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace spa
{
    public partial class login : Form
    {
        public login()
        {
            InitializeComponent();
        }

        

        private void btnclose_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are You Sure You Want To Close The Application", "Message", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning) == DialogResult.OK)
            {
                Application.Exit();
            }
            else
            {
                this.Show();
            }
            
        }

        private void btnlogin_Click(object sender, EventArgs e)
        {
            SqlConnection sqlConnection = new SqlConnection(@"Data Source=LAPTOP-1TTNHUIS\SQLEXPRESS;Initial Catalog=spamanagement;Integrated Security=True;Pooling=False");
            int i = 0;
            sqlConnection.Open();
            SqlCommand com = sqlConnection.CreateCommand();
            com.CommandType = CommandType.Text;
            com.CommandText = "Select empolyeeid, name, Username, password from employee where Username ='" + txtusername.Text + "' and Password= '" + txtpassword.Text + "' ";
            com.ExecuteNonQuery();
            DataTable d = new DataTable();
            SqlDataAdapter sd = new SqlDataAdapter(com);
            sd.Fill(d);
            


            //txtusername.Text = "";
            //txtpassword.Text = "";

            i = Convert.ToInt32(d.Rows.Count.ToString());

            if (i > 0)
            {
                MessageBox.Show("Successful login");
                Employees.uname = txtusername.Text;
                Employees.name = d.Rows[0][1].ToString();
                this.Hide();
                homeface homeface = new homeface();
                homeface.Show();
            }
            else
            {
                MessageBox.Show("Invalid username or password");
                txtpassword.Clear();
                txtusername.Clear();
            
            }
        }

        private void txtpassword_TextChanged(object sender, EventArgs e)
        {
            txtpassword.PasswordChar = '*'; 
        }
    }
}
