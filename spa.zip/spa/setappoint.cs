﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Drawing.Printing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace spa
{
    public partial class setappoint : Form
    {
       // private Invoice invoice;
        SqlConnection sqlConnection = new SqlConnection(@"Data Source=LAPTOP-1TTNHUIS\SQLEXPRESS;Initial Catalog=spamanagement;Integrated Security=True;Pooling=False");
        String servicetype;
        SqlCommand cmd;
        SqlDataReader reader;
        public setappoint()
        {
            InitializeComponent();
        }

        private void setappoint_Load(object sender, EventArgs e)
        {
            lblnameemployee.Text = Employees.name;
            lblusername.Text = Employees.uname;
            if (sqlConnection.State == ConnectionState.Open)
            {
                sqlConnection.Close();
            }
            sqlConnection.Open();
        }

        private void btnclose_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are You Sure You Want To Close The Application", "Message", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning) == DialogResult.OK)
            {
                Application.Exit();
            }
            else
            {
                this.Show();
            }
        }

        private void btndash_Click(object sender, EventArgs e)
        {
            this.Hide();
            homeface homeface = new homeface();
            homeface.Show();
        }

        private void btncreatecust_Click(object sender, EventArgs e)
        {
            this.Hide();
            createcust createcust = new createcust();
            createcust.Show();
        }

        private void btnsetappoint_Click(object sender, EventArgs e)
        {
            this.Hide();
            setappoint setappoint = new setappoint();
            setappoint.Show();
        }

        private void btnrecievepay_Click(object sender, EventArgs e)
        {
            this.Hide();
            payment payment = new payment();
            payment.Show();
        }

        private void btnlogout_Click(object sender, EventArgs e)
        {
            this.Hide();
            login login = new login();
            login.Show();
        }

        private void btnset_Click(object sender, EventArgs e)
        {
            try
            {
                cmd = sqlConnection.CreateCommand();

                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "Insert into appointment (name, email, dateofappointment, service_type, service, description, cost, amount, time, techname ) values ('" + txtname.Text + "', '" + txtemail.Text + "', '" + dateTimeappointment.Value + "', '" + servicetype + "', '" + service + "', '" + txtdesc.Text + "' , '" + txtcost.Text + "', '" + txtamount.Text + "', '" + txtsession.Text + "', '"+txttechname.Text+"')";
                cmd.ExecuteNonQuery();
                DataTable dt = new DataTable();
                SqlDataAdapter dataAdapter = new SqlDataAdapter(cmd);
                dataAdapter.Fill(dt);

                if (txtname.Text == "" || txtemail.Text == "" || service == null)
                {
                    MessageBox.Show("One or More Detail is missing");
                    
                }
                else
                {

                    MessageBox.Show(" An appointment was made ");
                    btnset.Hide();
                    btninvoice.Show();
            }
                }

                /*txtname.Text = "";
                txtemail.Text = "";
                txtcost.Text = "";
                txtamount.Text = "";
                txtsession.Text = "";
                txtdesc.Text = "";*/

            catch (Exception)
            {
                MessageBox.Show("An error has occured please enure that the correct data is being entered");
                this.Hide();
                setappoint setappoint = new setappoint();
                setappoint.Show();
            }
        }

        private void comboboxservicetype_SelectedIndexChanged(object sender, EventArgs e)
        {
            servicetype = comboboxservicetype.SelectedItem.ToString();

            if (servicetype == "Packages")
            {
                this.comboBoxpackage.Show();
                this.comboBoxSingles.Hide();
            }
            else if (servicetype == "Singles")
            {
                this.comboBoxSingles.Show();
                this.comboBoxpackage.Hide();
            }

        }
        String service;
        private void comboBoxpackage_SelectedIndexChanged(object sender, EventArgs e)
        {
            service = comboBoxpackage.SelectedItem.ToString();

            if (service == "Men Shave")
            {
                txtcost.Text = "2000";
                txtsession.Text = "2 hr 00 min";
                txtdesc.Text = "Package includes hair groom, beard and mustache groom, eyebrows and lashes groom";
                txttechname.Text = "Kenny Coore";
            }
            else if (service == "Men Facial")
            {
                txtcost.Text = "3500";
                txtsession.Text = "2 hr 45 min";
                txtdesc.Text = "Package includes all from men shave along with a deep facial massage";
                txttechname.Text = "Kenny Coore";
            }
            else if (service == "Women Facial")
            {
                txtcost.Text = "3800";
                txtsession.Text = "2 hr 45 min";
                txtdesc.Text = "Package includes deep facial massage, facial wax and detox";
                txttechname.Text = "Sherrie Dorms";
            }
            else if (service == "PediMani Combo")
            {
                txtcost.Text = "4500";
                txtsession.Text = "3 hr 00 min";
                txtdesc.Text = "Package includes Manciure and pedicure and polish nails desgin if your choice ";
                txttechname.Text = "Donna Smith";
            }
            else if (service == "Body Treatment Combo")
            {
                txtcost.Text = "8000";
                txtsession.Text = "3 hr 30 min";
                txtdesc.Text = "Package includes full body massages of your choice and all in PediMani Combo ";
                txttechname.Text = "Sally Richards";
            }
            else if (service == "Wedding Combo")
            {
                txtcost.Text = "16000";
                txtsession.Text = "5 hr 00 min";
                txtdesc.Text = "Package includes hairgrooming, facials, makeup, full body massage, Mani and Pedi and waxing for party of 6";
                txttechname.Text = "Amy Valarine";
            }
            else if (service == "Wax Combo")
            {
                txtcost.Text = "10000";
                txtsession.Text = "5 hr 00 min";
                txtdesc.Text = "Package includes full body wax";
                txttechname.Text = "Sally Richards";
            }
            else
            {
                MessageBox.Show("Invaild entry");
            }





        }

        private void comboBoxSingles_SelectedIndexChanged(object sender, EventArgs e)
        {
            service = comboBoxSingles.SelectedItem.ToString();

            if (service == "Haircut")
            {
                txtcost.Text = "800";
                txtsession.Text = "30 min";
                txtdesc.Text = "A hair cut of your choice";
                txttechname.Text = "Kenny Coore";
            }
            else if (service == "Oil Massage")
            {
                txtcost.Text = "5000";
                txtsession.Text = "1 hr 30 min";
                txtdesc.Text = "A full Massage with oils of your choice";
                txttechname.Text = "Sally Richards";
            }
            else if (service == "Manicure")
            {
                txtcost.Text = "2000";
                txtsession.Text = "45 min";
                txtdesc.Text = "Polish Job colour of your choice";
                txttechname.Text = "Donna Smith";
            }
            else if (service == "Pedicure")
            {
                txtcost.Text = "3000";
                txtsession.Text = "45 min";
                txtdesc.Text = "Polish Job colour of your choice";
                txttechname.Text = "Donna Smith";
            }
            else if (service == "Face Dextox")
            {
                txtcost.Text = "1200";
                txtsession.Text = "1 hr 45 min";
                txtdesc.Text = "Removal of dirt, blockheads and more from face";
                txttechname.Text = "Sherrie Dorms";
            }
            else if (service == "Hair wash")
            {
                txtcost.Text = "2500";
                txtsession.Text = "1 hr 00 min";
                txtdesc.Text = "Shampoo and conditioned hair style at a extra cost";
                txttechname.Text = "Kenny Moore";
            }
            else
            {
                MessageBox.Show("Invaild entry");
            }






        }

        

        private void btninvoice_Click(object sender, EventArgs e)
        {
            //sqlConnection.Open();
            SqlCommand com = sqlConnection.CreateCommand();
            com.CommandType = CommandType.Text;
            com.CommandText = "Insert into invoiceinfo (email) values ('" + txtemail.Text + "')";
            com.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter dataAdapter = new SqlDataAdapter(com);
            dataAdapter.Fill(dt);
            sqlConnection.Close();

           
            try
            {

                sqlConnection.Open();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "select * from invoice where appointmentid = (select Max(appointmentid) from invoice) and email = '"+txtemail.Text+"' ";
                reader = cmd.ExecuteReader();


                if (reader.Read())
                {
                    lblcustid.Text = reader["customerid"].ToString(); // row.Cells["customerid"].ToString();
                    lblinvoicename.Text = reader["name"].ToString(); //row.Cells["name"].ToString();
                    lblinvoiceemail.Text = reader["email"].ToString();  //row.Cells["email"].ToString();
                    lblcontact.Text = reader["contact"].ToString();  //row.Cells["contact"].ToString();
                    lblappoint.Text = reader["appointmentId"].ToString(); //row.Cells["appointmentId"].ToString();
                    lblinservicename.Text = reader["service"].ToString();// row.Cells["service"].ToString();
                    lbldescript.Text = reader["description"].ToString(); //row.Cells["description"].ToString();
                    lblinvoicecost.Text = reader["cost"].ToString(); //row.Cells["contact"].ToString();
                    lblserviceamt.Text = reader["amount"].ToString(); //row.Cells["amount"].ToString();
                    lblinvoiceid.Text = reader["invoice_id"].ToString(); //row.Cells["invoice_id"].ToString();
                    lbltotal.Text = reader["total"].ToString(); //row.Cells["total"].ToString();
                    lbltodaydate.Text = reader["date"].ToString(); //row.Cells["date"].ToString(); 
                    addappointment.Hide();
                    panelinvoice.Show();
                    panel3.Show();
                }
                else
                {
                    MessageBox.Show("Application Error ");
                    this.Hide();
                    addappointment.Show();
                }
                sqlConnection.Close();
            }
            catch
            {
                MessageBox.Show("Sorry something went wrong");
            }
            
            //addappointment.Hide();
        }
        Bitmap bmp;
        public void Print(Panel panel)
        {
            PrinterSettings pd = new PrinterSettings();
            panelinvoice = panel;
            getprintarea(panel);
            printPreviewDialog1.Document = printDocument1;
            printDocument1.PrintPage += new PrintPageEventHandler(printDocument1_PrintPage);
            printPreviewDialog1.ShowDialog();


        }

        public void getprintarea (Panel panel)
        {
            bmp = new Bitmap(panel.Width, panel.Height);
            panel.DrawToBitmap(bmp, new Rectangle (0, 0, panel.Width, panel.Height));
        }
        private void btnprint_Click(object sender, EventArgs e)
        {
            //MessageBox.Show("Sending to printer");
            Print(this.panelinvoice);
            this.Hide();
            setappoint setappoint = new setappoint();
            setappoint.Show();
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            Rectangle pagearea = e.PageBounds;
            e.Graphics.DrawImage(bmp,(pagearea.Width/2) - (this.panelinvoice.Width/2), this.panelinvoice.Location.Y);
        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}

