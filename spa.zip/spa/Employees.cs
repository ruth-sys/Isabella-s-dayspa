﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace spa
{
    class Employees
    {
        static string Uname;
        static String Name;

        public static String name
        {
            get
            {
                return Name;
            }
            set
            {
                Name = value;
            }
        }
        public static string uname
        {
            get
            {
                return Uname;
            }
            set
            {
                Uname = value;
            }
        }
    }
}
