﻿namespace spa
{
    partial class homeface
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.headerpanel = new System.Windows.Forms.Panel();
            this.btnclose = new System.Windows.Forms.Button();
            this.lblnameemployee = new System.Windows.Forms.Label();
            this.imguserlogin = new System.Windows.Forms.PictureBox();
            this.navpanel = new System.Windows.Forms.Panel();
            this.btncreatecust = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnlogout = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnrecievepay = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnsetappoint = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btndash = new Bunifu.Framework.UI.BunifuFlatButton();
            this.imglogo = new System.Windows.Forms.PictureBox();
            this.custinfo = new System.Windows.Forms.Panel();
            this.linkLabelcustomer = new System.Windows.Forms.LinkLabel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.appointmentinfo = new System.Windows.Forms.Panel();
            this.linkLabel3 = new System.Windows.Forms.LinkLabel();
            this.lblemployee = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.dragcontrol1 = new Bunifu.Framework.UI.BunifuDragControl(this.components);
            this.panel1 = new System.Windows.Forms.Panel();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.linkLabel2 = new System.Windows.Forms.LinkLabel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lblusername = new System.Windows.Forms.Label();
            this.headerpanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.imguserlogin)).BeginInit();
            this.navpanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.imglogo)).BeginInit();
            this.custinfo.SuspendLayout();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.appointmentinfo.SuspendLayout();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // headerpanel
            // 
            this.headerpanel.BackColor = System.Drawing.Color.DimGray;
            this.headerpanel.Controls.Add(this.lblusername);
            this.headerpanel.Controls.Add(this.btnclose);
            this.headerpanel.Controls.Add(this.lblnameemployee);
            this.headerpanel.Controls.Add(this.imguserlogin);
            this.headerpanel.Location = new System.Drawing.Point(1, 0);
            this.headerpanel.Name = "headerpanel";
            this.headerpanel.Size = new System.Drawing.Size(878, 76);
            this.headerpanel.TabIndex = 0;
            // 
            // btnclose
            // 
            this.btnclose.BackgroundImage = global::spa.Properties.Resources.close_button;
            this.btnclose.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnclose.Location = new System.Drawing.Point(840, 0);
            this.btnclose.Name = "btnclose";
            this.btnclose.Size = new System.Drawing.Size(38, 23);
            this.btnclose.TabIndex = 10;
            this.btnclose.UseVisualStyleBackColor = true;
            this.btnclose.Click += new System.EventHandler(this.btnclose_Click);
            // 
            // lblnameemployee
            // 
            this.lblnameemployee.AutoSize = true;
            this.lblnameemployee.Font = new System.Drawing.Font("Bradley Hand ITC", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblnameemployee.Location = new System.Drawing.Point(98, 12);
            this.lblnameemployee.Name = "lblnameemployee";
            this.lblnameemployee.Size = new System.Drawing.Size(216, 30);
            this.lblnameemployee.TabIndex = 2;
            this.lblnameemployee.Text = "Name of Employee";
            // 
            // imguserlogin
            // 
            this.imguserlogin.Image = global::spa.Properties.Resources.usernamelogin;
            this.imguserlogin.Location = new System.Drawing.Point(29, 12);
            this.imguserlogin.Name = "imguserlogin";
            this.imguserlogin.Size = new System.Drawing.Size(52, 47);
            this.imguserlogin.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.imguserlogin.TabIndex = 1;
            this.imguserlogin.TabStop = false;
            // 
            // navpanel
            // 
            this.navpanel.BackColor = System.Drawing.Color.DimGray;
            this.navpanel.Controls.Add(this.btncreatecust);
            this.navpanel.Controls.Add(this.btnlogout);
            this.navpanel.Controls.Add(this.btnrecievepay);
            this.navpanel.Controls.Add(this.btnsetappoint);
            this.navpanel.Controls.Add(this.btndash);
            this.navpanel.Controls.Add(this.imglogo);
            this.navpanel.Location = new System.Drawing.Point(1, 75);
            this.navpanel.Name = "navpanel";
            this.navpanel.Size = new System.Drawing.Size(247, 484);
            this.navpanel.TabIndex = 1;
            // 
            // btncreatecust
            // 
            this.btncreatecust.Activecolor = System.Drawing.Color.Lime;
            this.btncreatecust.BackColor = System.Drawing.Color.DimGray;
            this.btncreatecust.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btncreatecust.BorderRadius = 0;
            this.btncreatecust.ButtonText = "  CREATE NEW CUSTOMER";
            this.btncreatecust.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btncreatecust.DisabledColor = System.Drawing.Color.Gray;
            this.btncreatecust.Iconcolor = System.Drawing.Color.Transparent;
            this.btncreatecust.Iconimage = global::spa.Properties.Resources.customer;
            this.btncreatecust.Iconimage_right = null;
            this.btncreatecust.Iconimage_right_Selected = null;
            this.btncreatecust.Iconimage_Selected = null;
            this.btncreatecust.IconMarginLeft = 0;
            this.btncreatecust.IconMarginRight = 0;
            this.btncreatecust.IconRightVisible = true;
            this.btncreatecust.IconRightZoom = 0D;
            this.btncreatecust.IconVisible = true;
            this.btncreatecust.IconZoom = 60D;
            this.btncreatecust.IsTab = false;
            this.btncreatecust.Location = new System.Drawing.Point(0, 198);
            this.btncreatecust.Name = "btncreatecust";
            this.btncreatecust.Normalcolor = System.Drawing.Color.DimGray;
            this.btncreatecust.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.btncreatecust.OnHoverTextColor = System.Drawing.Color.White;
            this.btncreatecust.selected = false;
            this.btncreatecust.Size = new System.Drawing.Size(241, 48);
            this.btncreatecust.TabIndex = 7;
            this.btncreatecust.Text = "  CREATE NEW CUSTOMER";
            this.btncreatecust.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btncreatecust.Textcolor = System.Drawing.Color.White;
            this.btncreatecust.TextFont = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncreatecust.Click += new System.EventHandler(this.btncreatecust_Click);
            // 
            // btnlogout
            // 
            this.btnlogout.Activecolor = System.Drawing.Color.DimGray;
            this.btnlogout.BackColor = System.Drawing.Color.DimGray;
            this.btnlogout.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnlogout.BorderRadius = 0;
            this.btnlogout.ButtonText = "";
            this.btnlogout.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnlogout.DisabledColor = System.Drawing.Color.Gray;
            this.btnlogout.Iconcolor = System.Drawing.Color.Transparent;
            this.btnlogout.Iconimage = global::spa.Properties.Resources.logout;
            this.btnlogout.Iconimage_right = null;
            this.btnlogout.Iconimage_right_Selected = null;
            this.btnlogout.Iconimage_Selected = null;
            this.btnlogout.IconMarginLeft = 0;
            this.btnlogout.IconMarginRight = 0;
            this.btnlogout.IconRightVisible = true;
            this.btnlogout.IconRightZoom = 0D;
            this.btnlogout.IconVisible = true;
            this.btnlogout.IconZoom = 60D;
            this.btnlogout.IsTab = false;
            this.btnlogout.Location = new System.Drawing.Point(82, 405);
            this.btnlogout.Name = "btnlogout";
            this.btnlogout.Normalcolor = System.Drawing.Color.DimGray;
            this.btnlogout.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.btnlogout.OnHoverTextColor = System.Drawing.Color.White;
            this.btnlogout.selected = false;
            this.btnlogout.Size = new System.Drawing.Size(48, 48);
            this.btnlogout.TabIndex = 6;
            this.btnlogout.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnlogout.Textcolor = System.Drawing.Color.White;
            this.btnlogout.TextFont = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnlogout.Click += new System.EventHandler(this.btnlogout_Click);
            // 
            // btnrecievepay
            // 
            this.btnrecievepay.Activecolor = System.Drawing.Color.Lime;
            this.btnrecievepay.BackColor = System.Drawing.Color.DimGray;
            this.btnrecievepay.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnrecievepay.BorderRadius = 0;
            this.btnrecievepay.ButtonText = "  RECIEVE PAYEMENT";
            this.btnrecievepay.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnrecievepay.DisabledColor = System.Drawing.Color.Gray;
            this.btnrecievepay.Iconcolor = System.Drawing.Color.Transparent;
            this.btnrecievepay.Iconimage = global::spa.Properties.Resources.payment;
            this.btnrecievepay.Iconimage_right = null;
            this.btnrecievepay.Iconimage_right_Selected = null;
            this.btnrecievepay.Iconimage_Selected = null;
            this.btnrecievepay.IconMarginLeft = 0;
            this.btnrecievepay.IconMarginRight = 0;
            this.btnrecievepay.IconRightVisible = true;
            this.btnrecievepay.IconRightZoom = 0D;
            this.btnrecievepay.IconVisible = true;
            this.btnrecievepay.IconZoom = 60D;
            this.btnrecievepay.IsTab = false;
            this.btnrecievepay.Location = new System.Drawing.Point(0, 351);
            this.btnrecievepay.Name = "btnrecievepay";
            this.btnrecievepay.Normalcolor = System.Drawing.Color.DimGray;
            this.btnrecievepay.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.btnrecievepay.OnHoverTextColor = System.Drawing.Color.White;
            this.btnrecievepay.selected = false;
            this.btnrecievepay.Size = new System.Drawing.Size(241, 48);
            this.btnrecievepay.TabIndex = 5;
            this.btnrecievepay.Text = "  RECIEVE PAYEMENT";
            this.btnrecievepay.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnrecievepay.Textcolor = System.Drawing.Color.White;
            this.btnrecievepay.TextFont = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnrecievepay.Click += new System.EventHandler(this.btnrecievepay_Click);
            // 
            // btnsetappoint
            // 
            this.btnsetappoint.Activecolor = System.Drawing.Color.Lime;
            this.btnsetappoint.BackColor = System.Drawing.Color.DimGray;
            this.btnsetappoint.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnsetappoint.BorderRadius = 0;
            this.btnsetappoint.ButtonText = "  SET APPOINTMENT";
            this.btnsetappoint.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnsetappoint.DisabledColor = System.Drawing.Color.Gray;
            this.btnsetappoint.Iconcolor = System.Drawing.Color.Transparent;
            this.btnsetappoint.Iconimage = global::spa.Properties.Resources.appointment;
            this.btnsetappoint.Iconimage_right = null;
            this.btnsetappoint.Iconimage_right_Selected = null;
            this.btnsetappoint.Iconimage_Selected = null;
            this.btnsetappoint.IconMarginLeft = 0;
            this.btnsetappoint.IconMarginRight = 0;
            this.btnsetappoint.IconRightVisible = true;
            this.btnsetappoint.IconRightZoom = 0D;
            this.btnsetappoint.IconVisible = true;
            this.btnsetappoint.IconZoom = 60D;
            this.btnsetappoint.IsTab = false;
            this.btnsetappoint.Location = new System.Drawing.Point(0, 273);
            this.btnsetappoint.Name = "btnsetappoint";
            this.btnsetappoint.Normalcolor = System.Drawing.Color.DimGray;
            this.btnsetappoint.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.btnsetappoint.OnHoverTextColor = System.Drawing.Color.White;
            this.btnsetappoint.selected = false;
            this.btnsetappoint.Size = new System.Drawing.Size(241, 48);
            this.btnsetappoint.TabIndex = 4;
            this.btnsetappoint.Text = "  SET APPOINTMENT";
            this.btnsetappoint.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnsetappoint.Textcolor = System.Drawing.Color.White;
            this.btnsetappoint.TextFont = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsetappoint.Click += new System.EventHandler(this.btnsetappoint_Click);
            // 
            // btndash
            // 
            this.btndash.Activecolor = System.Drawing.Color.Lime;
            this.btndash.BackColor = System.Drawing.Color.Lime;
            this.btndash.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btndash.BorderRadius = 0;
            this.btndash.ButtonText = "    DASHBOARD";
            this.btndash.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btndash.DisabledColor = System.Drawing.Color.Gray;
            this.btndash.Iconcolor = System.Drawing.Color.Transparent;
            this.btndash.Iconimage = global::spa.Properties.Resources.dashboard;
            this.btndash.Iconimage_right = null;
            this.btndash.Iconimage_right_Selected = null;
            this.btndash.Iconimage_Selected = null;
            this.btndash.IconMarginLeft = 0;
            this.btndash.IconMarginRight = 0;
            this.btndash.IconRightVisible = true;
            this.btndash.IconRightZoom = 0D;
            this.btndash.IconVisible = true;
            this.btndash.IconZoom = 60D;
            this.btndash.IsTab = false;
            this.btndash.Location = new System.Drawing.Point(0, 124);
            this.btndash.Name = "btndash";
            this.btndash.Normalcolor = System.Drawing.Color.Lime;
            this.btndash.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.btndash.OnHoverTextColor = System.Drawing.Color.White;
            this.btndash.selected = true;
            this.btndash.Size = new System.Drawing.Size(241, 48);
            this.btndash.TabIndex = 3;
            this.btndash.Text = "    DASHBOARD";
            this.btndash.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btndash.Textcolor = System.Drawing.Color.White;
            this.btndash.TextFont = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btndash.Click += new System.EventHandler(this.btndash_Click);
            // 
            // imglogo
            // 
            this.imglogo.Image = global::spa.Properties.Resources.logo;
            this.imglogo.Location = new System.Drawing.Point(29, 7);
            this.imglogo.Name = "imglogo";
            this.imglogo.Size = new System.Drawing.Size(171, 76);
            this.imglogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.imglogo.TabIndex = 2;
            this.imglogo.TabStop = false;
            // 
            // custinfo
            // 
            this.custinfo.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.custinfo.Controls.Add(this.linkLabelcustomer);
            this.custinfo.Location = new System.Drawing.Point(317, 153);
            this.custinfo.Name = "custinfo";
            this.custinfo.Size = new System.Drawing.Size(196, 168);
            this.custinfo.TabIndex = 2;
            // 
            // linkLabelcustomer
            // 
            this.linkLabelcustomer.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabelcustomer.LinkVisited = true;
            this.linkLabelcustomer.Location = new System.Drawing.Point(18, 13);
            this.linkLabelcustomer.Name = "linkLabelcustomer";
            this.linkLabelcustomer.Size = new System.Drawing.Size(153, 52);
            this.linkLabelcustomer.TabIndex = 5;
            this.linkLabelcustomer.TabStop = true;
            this.linkLabelcustomer.Text = "Customer Information";
            this.linkLabelcustomer.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.linkLabelcustomer.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabelcustomer_LinkClicked);
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.White;
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel5.Controls.Add(this.pictureBox3);
            this.panel5.Location = new System.Drawing.Point(317, 238);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(196, 83);
            this.panel5.TabIndex = 0;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::spa.Properties.Resources.customer_info;
            this.pictureBox3.Location = new System.Drawing.Point(67, 16);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(66, 62);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 1;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // appointmentinfo
            // 
            this.appointmentinfo.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.appointmentinfo.Controls.Add(this.linkLabel3);
            this.appointmentinfo.Location = new System.Drawing.Point(317, 359);
            this.appointmentinfo.Name = "appointmentinfo";
            this.appointmentinfo.Size = new System.Drawing.Size(196, 169);
            this.appointmentinfo.TabIndex = 3;
            // 
            // linkLabel3
            // 
            this.linkLabel3.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabel3.LinkVisited = true;
            this.linkLabel3.Location = new System.Drawing.Point(18, 19);
            this.linkLabel3.Name = "linkLabel3";
            this.linkLabel3.Size = new System.Drawing.Size(168, 52);
            this.linkLabel3.TabIndex = 6;
            this.linkLabel3.TabStop = true;
            this.linkLabel3.Text = "Appointments";
            this.linkLabel3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.linkLabel3.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel3_LinkClicked);
            // 
            // lblemployee
            // 
            this.lblemployee.AutoSize = true;
            this.lblemployee.Font = new System.Drawing.Font("Algerian", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblemployee.Location = new System.Drawing.Point(409, 102);
            this.lblemployee.Name = "lblemployee";
            this.lblemployee.Size = new System.Drawing.Size(350, 21);
            this.lblemployee.TabIndex = 4;
            this.lblemployee.Text = "isabelles day spa management";
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.White;
            this.panel6.Controls.Add(this.pictureBox5);
            this.panel6.Location = new System.Drawing.Point(317, 454);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(196, 74);
            this.panel6.TabIndex = 1;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::spa.Properties.Resources.appointment_info;
            this.pictureBox5.Location = new System.Drawing.Point(53, 0);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(81, 71);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 1;
            this.pictureBox5.TabStop = false;
            this.pictureBox5.Click += new System.EventHandler(this.pictureBox5_Click);
            // 
            // dragcontrol1
            // 
            this.dragcontrol1.Fixed = true;
            this.dragcontrol1.Horizontal = true;
            this.dragcontrol1.TargetControl = this.headerpanel;
            this.dragcontrol1.Vertical = true;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.panel1.Controls.Add(this.linkLabel1);
            this.panel1.Location = new System.Drawing.Point(614, 153);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(196, 168);
            this.panel1.TabIndex = 4;
            // 
            // linkLabel1
            // 
            this.linkLabel1.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabel1.LinkVisited = true;
            this.linkLabel1.Location = new System.Drawing.Point(30, 13);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(153, 52);
            this.linkLabel1.TabIndex = 6;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "Invoices";
            this.linkLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.panel2.Controls.Add(this.linkLabel2);
            this.panel2.Controls.Add(this.panel4);
            this.panel2.Location = new System.Drawing.Point(614, 359);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(196, 168);
            this.panel2.TabIndex = 4;
            // 
            // linkLabel2
            // 
            this.linkLabel2.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabel2.LinkVisited = true;
            this.linkLabel2.Location = new System.Drawing.Point(21, 19);
            this.linkLabel2.Name = "linkLabel2";
            this.linkLabel2.Size = new System.Drawing.Size(153, 52);
            this.linkLabel2.TabIndex = 7;
            this.linkLabel2.TabStop = true;
            this.linkLabel2.Text = "Services details";
            this.linkLabel2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.linkLabel2.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel2_LinkClicked);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.White;
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel4.Controls.Add(this.pictureBox2);
            this.panel4.Location = new System.Drawing.Point(0, 86);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(196, 83);
            this.panel4.TabIndex = 1;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::spa.Properties.Resources.services1;
            this.pictureBox2.Location = new System.Drawing.Point(67, 8);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(66, 62);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 0;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.White;
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.pictureBox1);
            this.panel3.Location = new System.Drawing.Point(614, 238);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(196, 83);
            this.panel3.TabIndex = 1;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::spa.Properties.Resources.invoice;
            this.pictureBox1.Location = new System.Drawing.Point(67, 16);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(66, 62);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // lblusername
            // 
            this.lblusername.AutoSize = true;
            this.lblusername.Font = new System.Drawing.Font("Brush Script MT", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblusername.Location = new System.Drawing.Point(100, 42);
            this.lblusername.Name = "lblusername";
            this.lblusername.Size = new System.Drawing.Size(131, 17);
            this.lblusername.TabIndex = 11;
            this.lblusername.Text = "Username of Employee";
            // 
            // homeface
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Violet;
            this.ClientSize = new System.Drawing.Size(878, 561);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.lblemployee);
            this.Controls.Add(this.appointmentinfo);
            this.Controls.Add(this.custinfo);
            this.Controls.Add(this.navpanel);
            this.Controls.Add(this.headerpanel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "homeface";
            this.Text = "homeface";
            this.Load += new System.EventHandler(this.homeface_Load);
            this.headerpanel.ResumeLayout(false);
            this.headerpanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.imguserlogin)).EndInit();
            this.navpanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.imglogo)).EndInit();
            this.custinfo.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.appointmentinfo.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel headerpanel;
        private System.Windows.Forms.Panel navpanel;
        private System.Windows.Forms.Button btnclose;
        protected Bunifu.Framework.UI.BunifuFlatButton btndash;
        protected System.Windows.Forms.PictureBox imglogo;
        protected System.Windows.Forms.PictureBox imguserlogin;
        protected Bunifu.Framework.UI.BunifuFlatButton btnlogout;
        protected Bunifu.Framework.UI.BunifuFlatButton btnrecievepay;
        protected Bunifu.Framework.UI.BunifuFlatButton btnsetappoint;
        protected System.Windows.Forms.Label lblnameemployee;
        protected System.Windows.Forms.Panel custinfo;
        protected System.Windows.Forms.Panel panel5;
        protected System.Windows.Forms.Panel appointmentinfo;
        protected System.Windows.Forms.Label lblemployee;
        protected System.Windows.Forms.Panel panel6;
        protected System.Windows.Forms.PictureBox pictureBox5;
        protected Bunifu.Framework.UI.BunifuFlatButton btncreatecust;
        private Bunifu.Framework.UI.BunifuDragControl dragcontrol1;
        protected System.Windows.Forms.Panel panel1;
        protected System.Windows.Forms.Panel panel2;
        protected System.Windows.Forms.Panel panel4;
        protected System.Windows.Forms.PictureBox pictureBox2;
        protected System.Windows.Forms.Panel panel3;
        protected System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.LinkLabel linkLabelcustomer;
        private System.Windows.Forms.LinkLabel linkLabel3;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private System.Windows.Forms.LinkLabel linkLabel2;
        protected System.Windows.Forms.PictureBox pictureBox3;
        protected System.Windows.Forms.Label lblusername;
    }
}