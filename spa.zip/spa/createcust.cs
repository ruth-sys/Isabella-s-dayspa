﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Drawing.Text;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace spa
{
    public partial class createcust : Form
    {
        SqlConnection sqlConnection = new SqlConnection(@"Data Source=LAPTOP-1TTNHUIS\SQLEXPRESS;Initial Catalog=spamanagement;Integrated Security=True;Pooling=False");
        private char GENDER;

        public createcust()
        {
            InitializeComponent();
        }

        private void createcust_Load(object sender, EventArgs e)
        {
            lblnameemployee.Text = Employees.name;
            lblusername.Text = Employees.uname;

            if (sqlConnection.State == ConnectionState.Open)
            {
                sqlConnection.Close();
            }
            sqlConnection.Open();

            disp_data();
        }

        private void btndash_Click(object sender, EventArgs e)
        {
            this.Hide();
            homeface homeface = new homeface();
            homeface.Show();
        }

        private void btncreatecust_Click(object sender, EventArgs e)
        {
            this.Hide();
            createcust createcust = new createcust();
            createcust.Show();
        }

        private void btncreatcust(object sender, EventArgs e)
        {

        }

        private void btnsetappoint_Click(object sender, EventArgs e)
        {
            this.Hide();
            setappoint setappoint = new setappoint();
            setappoint.Show();
        }

        private void btnrecievepay_Click(object sender, EventArgs e)
        {
            this.Hide();
            payment payment = new payment();
            payment.Show();
        }

        private void btnlogout_Click(object sender, EventArgs e)
        {
            this.Hide();
            login login = new login();
            login.Show();
        }


        private void btnadd_Click(object sender, EventArgs e)
        {
            SqlCommand cmd = sqlConnection.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "Insert into customer (Name, Email, Contact, DOB, Gender) values ('" + txtname.Text + "', '" + txtemail.Text + "', '" + txtnumber.Text + "', '" + dtdob.Value + "', '" + GENDER + "')";
            cmd.ExecuteScalar();

            if (txtemail.Text == "" || txtname.Text == "")
            {
                MessageBox.Show("Error Customer Name or Email is Missing");
            }
            else
            {
                txtname.Text = "";
                txtemail.Text = "";
                txtnumber.Text = "";
                radioButtonfemale = null;
                radioButtonmale = null;
            
                disp_data();

                MessageBox.Show(" New Customer Added");

                this.Hide();
                setappoint setappoint = new setappoint();
                setappoint.Show();
            }

            

        }

        private void radioButtonmale_CheckedChanged(object sender, EventArgs e)
        {
            GENDER = 'M';
        }

        private void radioButtonfemale_CheckedChanged(object sender, EventArgs e)
        {
            GENDER = 'F';
        }

        public void disp_data()
        {
            SqlCommand cm = sqlConnection.CreateCommand();
            cm.CommandType = CommandType.Text;
            cm.CommandText = "Select * from customer";
            cm.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter dataAdapter = new SqlDataAdapter(cm);
            dataAdapter.Fill(dt);
            dataGridView1.DataSource = dt;
            
        }

        private void btnclose_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are You Sure You Want To Close The Application", "Message", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning) == DialogResult.OK)
            {
                Application.Exit();
            }
            else
            {
                this.Show();
            }
        }

        private void txtname_TextChanged(object sender, EventArgs e)
        {
            
        }

        
    }
}
