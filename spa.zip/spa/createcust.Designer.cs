﻿namespace spa
{
    partial class createcust
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblusername = new System.Windows.Forms.Label();
            this.btnclose = new System.Windows.Forms.Button();
            this.lblnameemployee = new System.Windows.Forms.Label();
            this.imguserlogin = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btncreatecust = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnlogout = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnrecievepay = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnsetappoint = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btndash = new Bunifu.Framework.UI.BunifuFlatButton();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.bunifuDragControl1 = new Bunifu.Framework.UI.BunifuDragControl(this.components);
            this.panel3 = new System.Windows.Forms.Panel();
            this.radioButtonfemale = new System.Windows.Forms.RadioButton();
            this.radioButtonmale = new System.Windows.Forms.RadioButton();
            this.lblgender = new System.Windows.Forms.Label();
            this.dtdob = new System.Windows.Forms.DateTimePicker();
            this.lblnumber = new System.Windows.Forms.Label();
            this.txtnumber = new System.Windows.Forms.TextBox();
            this.txtemail = new System.Windows.Forms.TextBox();
            this.lblemail = new System.Windows.Forms.Label();
            this.lbldob = new System.Windows.Forms.Label();
            this.btnadd = new System.Windows.Forms.Button();
            this.lblname = new System.Windows.Forms.Label();
            this.txtname = new System.Windows.Forms.TextBox();
            this.contextcust = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.imguserlogin)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.panel3.SuspendLayout();
            this.contextcust.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.DimGray;
            this.panel1.Controls.Add(this.lblusername);
            this.panel1.Controls.Add(this.btnclose);
            this.panel1.Controls.Add(this.lblnameemployee);
            this.panel1.Controls.Add(this.imguserlogin);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1094, 93);
            this.panel1.TabIndex = 1;
            // 
            // lblusername
            // 
            this.lblusername.AutoSize = true;
            this.lblusername.Font = new System.Drawing.Font("Brush Script MT", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblusername.Location = new System.Drawing.Point(89, 42);
            this.lblusername.Name = "lblusername";
            this.lblusername.Size = new System.Drawing.Size(131, 17);
            this.lblusername.TabIndex = 42;
            this.lblusername.Text = "Username of Employee";
            // 
            // btnclose
            // 
            this.btnclose.BackgroundImage = global::spa.Properties.Resources.close_button;
            this.btnclose.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnclose.Location = new System.Drawing.Point(1056, 0);
            this.btnclose.Name = "btnclose";
            this.btnclose.Size = new System.Drawing.Size(38, 23);
            this.btnclose.TabIndex = 10;
            this.btnclose.UseVisualStyleBackColor = true;
            this.btnclose.Click += new System.EventHandler(this.btnclose_Click);
            // 
            // lblnameemployee
            // 
            this.lblnameemployee.AutoSize = true;
            this.lblnameemployee.Font = new System.Drawing.Font("Bradley Hand ITC", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblnameemployee.Location = new System.Drawing.Point(87, 12);
            this.lblnameemployee.Name = "lblnameemployee";
            this.lblnameemployee.Size = new System.Drawing.Size(216, 30);
            this.lblnameemployee.TabIndex = 2;
            this.lblnameemployee.Text = "Name of Employee";
            // 
            // imguserlogin
            // 
            this.imguserlogin.Image = global::spa.Properties.Resources.usernamelogin;
            this.imguserlogin.Location = new System.Drawing.Point(29, 12);
            this.imguserlogin.Name = "imguserlogin";
            this.imguserlogin.Size = new System.Drawing.Size(52, 47);
            this.imguserlogin.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.imguserlogin.TabIndex = 1;
            this.imguserlogin.TabStop = false;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.DimGray;
            this.panel2.Controls.Add(this.btncreatecust);
            this.panel2.Controls.Add(this.btnlogout);
            this.panel2.Controls.Add(this.btnrecievepay);
            this.panel2.Controls.Add(this.btnsetappoint);
            this.panel2.Controls.Add(this.btndash);
            this.panel2.Controls.Add(this.pictureBox1);
            this.panel2.Location = new System.Drawing.Point(0, 82);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(247, 519);
            this.panel2.TabIndex = 2;
            // 
            // btncreatecust
            // 
            this.btncreatecust.Activecolor = System.Drawing.Color.Lime;
            this.btncreatecust.BackColor = System.Drawing.Color.Lime;
            this.btncreatecust.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btncreatecust.BorderRadius = 0;
            this.btncreatecust.ButtonText = "   CREATE CUSTOMER";
            this.btncreatecust.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btncreatecust.DisabledColor = System.Drawing.Color.Gray;
            this.btncreatecust.Iconcolor = System.Drawing.Color.Transparent;
            this.btncreatecust.Iconimage = global::spa.Properties.Resources.customer;
            this.btncreatecust.Iconimage_right = null;
            this.btncreatecust.Iconimage_right_Selected = null;
            this.btncreatecust.Iconimage_Selected = null;
            this.btncreatecust.IconMarginLeft = 0;
            this.btncreatecust.IconMarginRight = 0;
            this.btncreatecust.IconRightVisible = true;
            this.btncreatecust.IconRightZoom = 0D;
            this.btncreatecust.IconVisible = true;
            this.btncreatecust.IconZoom = 60D;
            this.btncreatecust.IsTab = false;
            this.btncreatecust.Location = new System.Drawing.Point(0, 198);
            this.btncreatecust.Name = "btncreatecust";
            this.btncreatecust.Normalcolor = System.Drawing.Color.Lime;
            this.btncreatecust.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.btncreatecust.OnHoverTextColor = System.Drawing.Color.White;
            this.btncreatecust.selected = true;
            this.btncreatecust.Size = new System.Drawing.Size(241, 48);
            this.btncreatecust.TabIndex = 7;
            this.btncreatecust.Text = "   CREATE CUSTOMER";
            this.btncreatecust.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btncreatecust.Textcolor = System.Drawing.Color.White;
            this.btncreatecust.TextFont = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncreatecust.Click += new System.EventHandler(this.btncreatecust_Click);
            // 
            // btnlogout
            // 
            this.btnlogout.Activecolor = System.Drawing.Color.DimGray;
            this.btnlogout.BackColor = System.Drawing.Color.DimGray;
            this.btnlogout.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnlogout.BorderRadius = 0;
            this.btnlogout.ButtonText = "";
            this.btnlogout.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnlogout.DisabledColor = System.Drawing.Color.Gray;
            this.btnlogout.Iconcolor = System.Drawing.Color.Transparent;
            this.btnlogout.Iconimage = global::spa.Properties.Resources.logout;
            this.btnlogout.Iconimage_right = null;
            this.btnlogout.Iconimage_right_Selected = null;
            this.btnlogout.Iconimage_Selected = null;
            this.btnlogout.IconMarginLeft = 0;
            this.btnlogout.IconMarginRight = 0;
            this.btnlogout.IconRightVisible = true;
            this.btnlogout.IconRightZoom = 0D;
            this.btnlogout.IconVisible = true;
            this.btnlogout.IconZoom = 60D;
            this.btnlogout.IsTab = false;
            this.btnlogout.Location = new System.Drawing.Point(82, 405);
            this.btnlogout.Name = "btnlogout";
            this.btnlogout.Normalcolor = System.Drawing.Color.DimGray;
            this.btnlogout.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.btnlogout.OnHoverTextColor = System.Drawing.Color.White;
            this.btnlogout.selected = false;
            this.btnlogout.Size = new System.Drawing.Size(48, 48);
            this.btnlogout.TabIndex = 6;
            this.btnlogout.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnlogout.Textcolor = System.Drawing.Color.White;
            this.btnlogout.TextFont = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnlogout.Click += new System.EventHandler(this.btnlogout_Click);
            // 
            // btnrecievepay
            // 
            this.btnrecievepay.Activecolor = System.Drawing.Color.DimGray;
            this.btnrecievepay.BackColor = System.Drawing.Color.DimGray;
            this.btnrecievepay.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnrecievepay.BorderRadius = 0;
            this.btnrecievepay.ButtonText = "  RECIEVE PAYEMENT";
            this.btnrecievepay.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnrecievepay.DisabledColor = System.Drawing.Color.Gray;
            this.btnrecievepay.Iconcolor = System.Drawing.Color.Transparent;
            this.btnrecievepay.Iconimage = global::spa.Properties.Resources.payment;
            this.btnrecievepay.Iconimage_right = null;
            this.btnrecievepay.Iconimage_right_Selected = null;
            this.btnrecievepay.Iconimage_Selected = null;
            this.btnrecievepay.IconMarginLeft = 0;
            this.btnrecievepay.IconMarginRight = 0;
            this.btnrecievepay.IconRightVisible = true;
            this.btnrecievepay.IconRightZoom = 0D;
            this.btnrecievepay.IconVisible = true;
            this.btnrecievepay.IconZoom = 60D;
            this.btnrecievepay.IsTab = false;
            this.btnrecievepay.Location = new System.Drawing.Point(0, 351);
            this.btnrecievepay.Name = "btnrecievepay";
            this.btnrecievepay.Normalcolor = System.Drawing.Color.DimGray;
            this.btnrecievepay.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.btnrecievepay.OnHoverTextColor = System.Drawing.Color.White;
            this.btnrecievepay.selected = false;
            this.btnrecievepay.Size = new System.Drawing.Size(241, 48);
            this.btnrecievepay.TabIndex = 5;
            this.btnrecievepay.Text = "  RECIEVE PAYEMENT";
            this.btnrecievepay.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnrecievepay.Textcolor = System.Drawing.Color.White;
            this.btnrecievepay.TextFont = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnrecievepay.Click += new System.EventHandler(this.btnrecievepay_Click);
            // 
            // btnsetappoint
            // 
            this.btnsetappoint.Activecolor = System.Drawing.Color.DimGray;
            this.btnsetappoint.BackColor = System.Drawing.Color.DimGray;
            this.btnsetappoint.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnsetappoint.BorderRadius = 0;
            this.btnsetappoint.ButtonText = "  SET APPOINTMENT";
            this.btnsetappoint.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnsetappoint.DisabledColor = System.Drawing.Color.Gray;
            this.btnsetappoint.Iconcolor = System.Drawing.Color.Transparent;
            this.btnsetappoint.Iconimage = global::spa.Properties.Resources.appointment;
            this.btnsetappoint.Iconimage_right = null;
            this.btnsetappoint.Iconimage_right_Selected = null;
            this.btnsetappoint.Iconimage_Selected = null;
            this.btnsetappoint.IconMarginLeft = 0;
            this.btnsetappoint.IconMarginRight = 0;
            this.btnsetappoint.IconRightVisible = true;
            this.btnsetappoint.IconRightZoom = 0D;
            this.btnsetappoint.IconVisible = true;
            this.btnsetappoint.IconZoom = 60D;
            this.btnsetappoint.IsTab = false;
            this.btnsetappoint.Location = new System.Drawing.Point(0, 273);
            this.btnsetappoint.Name = "btnsetappoint";
            this.btnsetappoint.Normalcolor = System.Drawing.Color.DimGray;
            this.btnsetappoint.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.btnsetappoint.OnHoverTextColor = System.Drawing.Color.White;
            this.btnsetappoint.selected = false;
            this.btnsetappoint.Size = new System.Drawing.Size(241, 48);
            this.btnsetappoint.TabIndex = 4;
            this.btnsetappoint.Text = "  SET APPOINTMENT";
            this.btnsetappoint.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnsetappoint.Textcolor = System.Drawing.Color.White;
            this.btnsetappoint.TextFont = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsetappoint.Click += new System.EventHandler(this.btnsetappoint_Click);
            // 
            // btndash
            // 
            this.btndash.Activecolor = System.Drawing.Color.DimGray;
            this.btndash.BackColor = System.Drawing.Color.DimGray;
            this.btndash.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btndash.BorderRadius = 0;
            this.btndash.ButtonText = "    DASHBOARD";
            this.btndash.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btndash.DisabledColor = System.Drawing.Color.Gray;
            this.btndash.Iconcolor = System.Drawing.Color.Transparent;
            this.btndash.Iconimage = global::spa.Properties.Resources.dashboard;
            this.btndash.Iconimage_right = null;
            this.btndash.Iconimage_right_Selected = null;
            this.btndash.Iconimage_Selected = null;
            this.btndash.IconMarginLeft = 0;
            this.btndash.IconMarginRight = 0;
            this.btndash.IconRightVisible = true;
            this.btndash.IconRightZoom = 0D;
            this.btndash.IconVisible = true;
            this.btndash.IconZoom = 60D;
            this.btndash.IsTab = false;
            this.btndash.Location = new System.Drawing.Point(0, 124);
            this.btndash.Name = "btndash";
            this.btndash.Normalcolor = System.Drawing.Color.DimGray;
            this.btndash.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.btndash.OnHoverTextColor = System.Drawing.Color.White;
            this.btndash.selected = false;
            this.btndash.Size = new System.Drawing.Size(241, 48);
            this.btndash.TabIndex = 3;
            this.btndash.Text = "    DASHBOARD";
            this.btndash.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btndash.Textcolor = System.Drawing.Color.White;
            this.btndash.TextFont = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btndash.Click += new System.EventHandler(this.btndash_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::spa.Properties.Resources.logo;
            this.pictureBox1.Location = new System.Drawing.Point(29, 17);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(171, 76);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.dataGridView1);
            this.panel4.Location = new System.Drawing.Point(253, 357);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(841, 226);
            this.panel4.TabIndex = 4;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AllowUserToOrderColumns = true;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.Aquamarine;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.Navy;
            this.dataGridView1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.DeepSkyBlue;
            this.dataGridView1.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.Teal;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.Navy;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.LightSeaGreen;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.Navy;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView1.DefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridView1.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter;
            this.dataGridView1.GridColor = System.Drawing.Color.Lime;
            this.dataGridView1.Location = new System.Drawing.Point(116, 28);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.ReadOnly = true;
            this.dataGridView1.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.Size = new System.Drawing.Size(643, 150);
            this.dataGridView1.TabIndex = 0;
            // 
            // bunifuDragControl1
            // 
            this.bunifuDragControl1.Fixed = true;
            this.bunifuDragControl1.Horizontal = true;
            this.bunifuDragControl1.TargetControl = this.panel1;
            this.bunifuDragControl1.Vertical = true;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.radioButtonfemale);
            this.panel3.Controls.Add(this.radioButtonmale);
            this.panel3.Controls.Add(this.lblgender);
            this.panel3.Controls.Add(this.dtdob);
            this.panel3.Controls.Add(this.lblnumber);
            this.panel3.Controls.Add(this.txtnumber);
            this.panel3.Controls.Add(this.txtemail);
            this.panel3.Controls.Add(this.lblemail);
            this.panel3.Controls.Add(this.lbldob);
            this.panel3.Controls.Add(this.btnadd);
            this.panel3.Controls.Add(this.lblname);
            this.panel3.Controls.Add(this.txtname);
            this.panel3.Location = new System.Drawing.Point(3, 3);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(841, 246);
            this.panel3.TabIndex = 9;
            // 
            // radioButtonfemale
            // 
            this.radioButtonfemale.AutoSize = true;
            this.radioButtonfemale.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtonfemale.Location = new System.Drawing.Point(701, 108);
            this.radioButtonfemale.Name = "radioButtonfemale";
            this.radioButtonfemale.Size = new System.Drawing.Size(71, 23);
            this.radioButtonfemale.TabIndex = 17;
            this.radioButtonfemale.TabStop = true;
            this.radioButtonfemale.Text = "Female";
            this.radioButtonfemale.UseVisualStyleBackColor = true;
            this.radioButtonfemale.CheckedChanged += new System.EventHandler(this.radioButtonfemale_CheckedChanged);
            // 
            // radioButtonmale
            // 
            this.radioButtonmale.AutoSize = true;
            this.radioButtonmale.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtonmale.Location = new System.Drawing.Point(572, 108);
            this.radioButtonmale.Name = "radioButtonmale";
            this.radioButtonmale.Size = new System.Drawing.Size(58, 23);
            this.radioButtonmale.TabIndex = 16;
            this.radioButtonmale.TabStop = true;
            this.radioButtonmale.Text = "Male";
            this.radioButtonmale.UseVisualStyleBackColor = true;
            this.radioButtonmale.CheckedChanged += new System.EventHandler(this.radioButtonmale_CheckedChanged);
            // 
            // lblgender
            // 
            this.lblgender.AutoSize = true;
            this.lblgender.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblgender.Location = new System.Drawing.Point(417, 108);
            this.lblgender.Name = "lblgender";
            this.lblgender.Size = new System.Drawing.Size(76, 25);
            this.lblgender.TabIndex = 15;
            this.lblgender.Text = "Gender";
            // 
            // dtdob
            // 
            this.dtdob.CalendarMonthBackground = System.Drawing.Color.White;
            this.dtdob.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtdob.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtdob.Location = new System.Drawing.Point(572, 36);
            this.dtdob.Name = "dtdob";
            this.dtdob.Size = new System.Drawing.Size(200, 26);
            this.dtdob.TabIndex = 14;
            this.dtdob.Value = new System.DateTime(2020, 3, 21, 0, 0, 0, 0);
            // 
            // lblnumber
            // 
            this.lblnumber.AutoSize = true;
            this.lblnumber.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblnumber.Location = new System.Drawing.Point(14, 164);
            this.lblnumber.Name = "lblnumber";
            this.lblnumber.Size = new System.Drawing.Size(80, 25);
            this.lblnumber.TabIndex = 13;
            this.lblnumber.Text = "Contact";
            // 
            // txtnumber
            // 
            this.txtnumber.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtnumber.Location = new System.Drawing.Point(137, 164);
            this.txtnumber.Multiline = true;
            this.txtnumber.Name = "txtnumber";
            this.txtnumber.Size = new System.Drawing.Size(186, 25);
            this.txtnumber.TabIndex = 12;
            // 
            // txtemail
            // 
            this.txtemail.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtemail.Location = new System.Drawing.Point(137, 102);
            this.txtemail.Multiline = true;
            this.txtemail.Name = "txtemail";
            this.txtemail.Size = new System.Drawing.Size(186, 28);
            this.txtemail.TabIndex = 11;
            // 
            // lblemail
            // 
            this.lblemail.AutoSize = true;
            this.lblemail.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblemail.Location = new System.Drawing.Point(26, 105);
            this.lblemail.Name = "lblemail";
            this.lblemail.Size = new System.Drawing.Size(63, 25);
            this.lblemail.TabIndex = 10;
            this.lblemail.Text = "Email";
            // 
            // lbldob
            // 
            this.lbldob.AutoSize = true;
            this.lbldob.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbldob.Location = new System.Drawing.Point(417, 39);
            this.lbldob.Name = "lbldob";
            this.lbldob.Size = new System.Drawing.Size(127, 25);
            this.lbldob.TabIndex = 9;
            this.lbldob.Text = "Date of Birth";
            // 
            // btnadd
            // 
            this.btnadd.BackColor = System.Drawing.Color.GreenYellow;
            this.btnadd.FlatAppearance.BorderColor = System.Drawing.Color.Green;
            this.btnadd.FlatAppearance.BorderSize = 5;
            this.btnadd.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.btnadd.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Lime;
            this.btnadd.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnadd.Location = new System.Drawing.Point(679, 198);
            this.btnadd.Name = "btnadd";
            this.btnadd.Size = new System.Drawing.Size(152, 36);
            this.btnadd.TabIndex = 4;
            this.btnadd.Text = "Add customer";
            this.btnadd.UseVisualStyleBackColor = false;
            this.btnadd.Click += new System.EventHandler(this.btnadd_Click);
            // 
            // lblname
            // 
            this.lblname.AutoSize = true;
            this.lblname.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblname.Location = new System.Drawing.Point(26, 39);
            this.lblname.Name = "lblname";
            this.lblname.Size = new System.Drawing.Size(64, 25);
            this.lblname.TabIndex = 0;
            this.lblname.Text = "Name";
            // 
            // txtname
            // 
            this.txtname.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtname.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.HistoryList;
            this.txtname.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtname.ForeColor = System.Drawing.Color.Black;
            this.txtname.Location = new System.Drawing.Point(137, 32);
            this.txtname.Multiline = true;
            this.txtname.Name = "txtname";
            this.txtname.Size = new System.Drawing.Size(186, 30);
            this.txtname.TabIndex = 5;
            this.txtname.TextChanged += new System.EventHandler(this.txtname_TextChanged);
            // 
            // contextcust
            // 
            this.contextcust.AutoSize = true;
            this.contextcust.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.contextcust.Controls.Add(this.panel3);
            this.contextcust.Location = new System.Drawing.Point(247, 99);
            this.contextcust.Name = "contextcust";
            this.contextcust.Size = new System.Drawing.Size(847, 252);
            this.contextcust.TabIndex = 3;
            // 
            // createcust
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Violet;
            this.ClientSize = new System.Drawing.Size(1096, 595);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.contextcust);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "createcust";
            this.Text = "createcust";
            this.Load += new System.EventHandler(this.createcust_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.imguserlogin)).EndInit();
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.contextcust.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnclose;
        protected System.Windows.Forms.Label lblnameemployee;
        protected System.Windows.Forms.PictureBox imguserlogin;
        private System.Windows.Forms.Panel panel2;
        protected Bunifu.Framework.UI.BunifuFlatButton btnlogout;
        protected Bunifu.Framework.UI.BunifuFlatButton btnrecievepay;
        protected Bunifu.Framework.UI.BunifuFlatButton btnsetappoint;
        protected Bunifu.Framework.UI.BunifuFlatButton btndash;
        protected System.Windows.Forms.PictureBox pictureBox1;
        protected Bunifu.Framework.UI.BunifuFlatButton btncreatecust;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.DataGridView dataGridView1;
        private Bunifu.Framework.UI.BunifuDragControl bunifuDragControl1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.RadioButton radioButtonfemale;
        private System.Windows.Forms.RadioButton radioButtonmale;
        private System.Windows.Forms.Label lblgender;
        private System.Windows.Forms.DateTimePicker dtdob;
        private System.Windows.Forms.Label lblnumber;
        private System.Windows.Forms.TextBox txtnumber;
        private System.Windows.Forms.TextBox txtemail;
        private System.Windows.Forms.Label lblemail;
        private System.Windows.Forms.Label lbldob;
        private System.Windows.Forms.Button btnadd;
        private System.Windows.Forms.Label lblname;
        private System.Windows.Forms.TextBox txtname;
        private System.Windows.Forms.Panel contextcust;
        protected System.Windows.Forms.Label lblusername;
    }
}